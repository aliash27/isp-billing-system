import { db } from "@/db";
import {
  tenants,
  users,
  subscriptionPlans,
  subscribers,
  payments,
  debts,
  receiptTemplates,
} from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { eq, sql } from "drizzle-orm";
import { slugify } from "@/lib/utils";

export async function seedDatabase() {
  // Default subscription plans (global)
  const existingPlans = await db.select().from(subscriptionPlans).limit(1);
  if (existingPlans.length === 0) {
    await db.insert(subscriptionPlans).values([
      {
        name: "Free Trial",
        code: "trial",
        durationDays: 14,
        price: "0",
        features: ["All features", "Up to 50 subscribers"],
      },
      {
        name: "Monthly",
        code: "monthly",
        durationDays: 30,
        price: "49",
        features: ["All features", "Up to 500 subscribers"],
      },
      {
        name: "Quarterly",
        code: "quarterly",
        durationDays: 90,
        price: "129",
        features: ["All features", "Up to 2000 subscribers", "Priority support"],
      },
      {
        name: "Semi-annual",
        code: "semi_annual",
        durationDays: 180,
        price: "229",
        features: ["All features", "Unlimited subscribers", "Priority support"],
      },
      {
        name: "Annual",
        code: "annual",
        durationDays: 365,
        price: "399",
        features: ["All features", "Unlimited subscribers", "Dedicated support"],
      },
    ]);
  }

  // Super admin
  const existingSuperAdmin = await db
    .select()
    .from(users)
    .where(eq(users.role, "super_admin"))
    .limit(1);

  if (existingSuperAdmin.length === 0) {
    const pwHash = await hashPassword("admin123");
    await db.insert(users).values({
      role: "super_admin",
      fullName: "Super Admin",
      email: "super@isp.local",
      passwordHash: pwHash,
      status: "active",
    });
  }

  // Demo tenant + admin
  const existingTenant = await db
    .select()
    .from(tenants)
    .where(eq(tenants.slug, "demo-net"))
    .limit(1);

  if (existingTenant.length === 0) {
    const trialEnds = new Date();
    trialEnds.setDate(trialEnds.getDate() + 14);
    const [tenant] = await db
      .insert(tenants)
      .values({
        name: "Demo Net ISP",
        slug: "demo-net",
        phone: "+966501234567",
        email: "admin@demo-net.local",
        address: "Riyadh, Saudi Arabia",
        country: "SA",
        currency: "SAR",
        locale: "ar",
        status: "active",
        trialEndsAt: trialEnds,
        subscriptionStartsAt: new Date(),
        subscriptionEndsAt: (() => {
          const d = new Date();
          d.setFullYear(d.getFullYear() + 1);
          return d;
        })(),
      })
      .returning();

    // Admin user
    const adminHash = await hashPassword("admin123");
    const [admin] = await db
      .insert(users)
      .values({
        tenantId: tenant.id,
        role: "admin",
        fullName: "Ahmad Admin",
        email: "admin@demo-net.local",
        passwordHash: adminHash,
        status: "active",
      })
      .returning();

    // Accountant user
    const acctHash = await hashPassword("admin123");
    await db.insert(users).values({
      tenantId: tenant.id,
      role: "accountant",
      fullName: "Sara Accountant",
      email: "accountant@demo-net.local",
      passwordHash: acctHash,
      status: "active",
      approvedAt: new Date(),
      approvedBy: admin.id,
    });

    // Receipt template
    await db.insert(receiptTemplates).values({
      tenantId: tenant.id,
      headerTitle: "إيصال قبض / Receipt",
      footerText: "جميع الحقوق محفوظة © Demo Net ISP",
      accentColor: "#0ea5e9",
      thankYouMessage: "شكراً لتعاملكم معنا - Thank you",
    });

    // Seed subscribers
    const subs = [
      {
        fullName: "محمد العتيبي",
        phone: "0551234567",
        address: "الرياض - حي النرجس",
        area: "الرياض",
        subscriptionType: "monthly" as const,
        monthlyFee: "150",
        dueDate: "05",
        debtAmount: "0",
        status: "active" as const,
      },
      {
        fullName: "فاطمة الزهراني",
        phone: "0559876543",
        address: "جدة - حي الروضة",
        area: "جدة",
        subscriptionType: "quarterly" as const,
        monthlyFee: "140",
        dueDate: "10",
        debtAmount: "140",
        status: "active" as const,
      },
      {
        fullName: "خالد القحطاني",
        phone: "0541112233",
        address: "الدمام - حي الشاطئ",
        area: "الدمام",
        subscriptionType: "monthly" as const,
        monthlyFee: "160",
        dueDate: "15",
        debtAmount: "320",
        status: "active" as const,
      },
      {
        fullName: "نورة السبيعي",
        phone: "0567778899",
        address: "الرياض - حي العليا",
        area: "الرياض",
        subscriptionType: "annual" as const,
        monthlyFee: "130",
        dueDate: "20",
        debtAmount: "0",
        status: "active" as const,
      },
      {
        fullName: "عبدالله الغامدي",
        phone: "0533445566",
        address: "مكة - حي العزيزية",
        area: "مكة",
        subscriptionType: "monthly" as const,
        monthlyFee: "150",
        dueDate: "25",
        debtAmount: "450",
        status: "expired" as const,
      },
      {
        fullName: "ريم الحربي",
        phone: "0522113344",
        address: "المدينة - حي الشهداء",
        area: "المدينة",
        subscriptionType: "semi_annual" as const,
        monthlyFee: "135",
        dueDate: "01",
        debtAmount: "0",
        status: "active" as const,
      },
      {
        fullName: "John Smith",
        phone: "0577889900",
        address: "Riyadh - Al Malqa",
        area: "Riyadh",
        subscriptionType: "monthly" as const,
        monthlyFee: "180",
        dueDate: "05",
        debtAmount: "180",
        status: "active" as const,
      },
      {
        fullName: "سارة المطيري",
        phone: "0566554433",
        address: "الرياض - حي الياسمين",
        area: "الرياض",
        subscriptionType: "quarterly" as const,
        monthlyFee: "145",
        dueDate: "12",
        debtAmount: "0",
        status: "active" as const,
      },
    ];

    const createdSubs = await db
      .insert(subscribers)
      .values(
        subs.map((s) => ({
          ...s,
          tenantId: tenant.id,
          createdBy: admin.id,
          nextBillingAt: new Date(Date.now() + 15 * 86400000),
        }))
      )
      .returning();

    // Seed payments for the last 60 days
    const receiptBase = 1000;
    for (let i = 0; i < 14; i++) {
      const sub = createdSubs[i % createdSubs.length];
      const daysAgo = Math.floor(Math.random() * 60);
      const paidAt = new Date();
      paidAt.setDate(paidAt.getDate() - daysAgo);
      const amount = Number(sub.monthlyFee);
      const receiptNumber = `RCP-${paidAt.getFullYear()}${String(paidAt.getMonth() + 1).padStart(2, "0")}${String(paidAt.getDate()).padStart(2, "0")}-${receiptBase + i}`;
      const [payment] = await db
        .insert(payments)
        .values({
          tenantId: tenant.id,
          subscriberId: sub.id,
          receiptNumber,
          amount: String(amount),
          method: ["cash", "card", "transfer"][i % 3] as
            | "cash"
            | "card"
            | "transfer",
          type: "subscription",
          monthsCovered: "1",
          paidAt,
        })
        .returning();

      // Add matching debt record
      await db.insert(debts).values({
        tenantId: tenant.id,
        subscriberId: sub.id,
        paymentId: payment.id,
        amount: String(amount),
        remaining: "0",
        type: "payment",
        description: "Payment received",
      });
    }
  }

  return { ok: true };
}

// Helper for SQL reset
export async function wipeDatabase() {
  await db.execute(sql`truncate table audit_logs, debts, payments, invoices, subscription_logs, subscribers, receipt_templates, settings, users, tenants, subscription_plans cascade`);
}
