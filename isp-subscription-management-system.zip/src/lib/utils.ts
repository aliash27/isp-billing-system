import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import type { Lang } from "./i18n";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatMoney(
  value: number | string | null | undefined,
  currency = "SAR",
  lang: Lang = "ar"
): string {
  const num = typeof value === "string" ? parseFloat(value) : (value ?? 0);
  try {
    return new Intl.NumberFormat(lang === "ar" ? "ar-SA" : "en-US", {
      style: "currency",
      currency,
      maximumFractionDigits: 2,
    }).format(isNaN(num) ? 0 : num);
  } catch {
    return `${(isNaN(num) ? 0 : num).toFixed(2)} ${currency}`;
  }
}

export function formatDate(
  value: Date | string | null | undefined,
  lang: Lang = "ar",
  opts: Intl.DateTimeFormatOptions = {
    year: "numeric",
    month: "short",
    day: "2-digit",
  }
): string {
  if (!value) return "—";
  const d = typeof value === "string" ? new Date(value) : value;
  if (isNaN(d.getTime())) return "—";
  try {
    return new Intl.DateTimeFormat(
      lang === "ar" ? "ar-SA" : "en-US",
      opts
    ).format(d);
  } catch {
    return d.toISOString();
  }
}

export function formatDateTime(
  value: Date | string | null | undefined,
  lang: Lang = "ar"
) {
  return formatDate(value, lang, {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function numberToWordsAr(n: number): string {
  // Simplified Arabic number-to-words (up to millions) for receipts
  if (n === 0) return "صفر";
  const ones = [
    "",
    "واحد",
    "اثنان",
    "ثلاثة",
    "أربعة",
    "خمسة",
    "ستة",
    "سبعة",
    "ثمانية",
    "تسعة",
    "عشرة",
    "أحد عشر",
    "اثنا عشر",
    "ثلاثة عشر",
    "أربعة عشر",
    "خمسة عشر",
    "ستة عشر",
    "سبعة عشر",
    "ثمانية عشر",
    "تسعة عشر",
  ];
  const tens = [
    "",
    "",
    "عشرون",
    "ثلاثون",
    "أربعون",
    "خمسون",
    "ستون",
    "سبعون",
    "ثمانون",
    "تسعون",
  ];
  const hundreds = [
    "",
    "مائة",
    "مئتان",
    "ثلاثمائة",
    "أربعمائة",
    "خمسمائة",
    "ستمائة",
    "سبعمائة",
    "ثمانمائة",
    "تسعمائة",
  ];

  const chunk = (num: number): string => {
    if (num === 0) return "";
    if (num < 20) return ones[num];
    if (num < 100) {
      const t = Math.floor(num / 10);
      const o = num % 10;
      return o ? `${ones[o]} و${tens[t]}` : tens[t];
    }
    const h = Math.floor(num / 100);
    const rem = num % 100;
    return rem ? `${hundreds[h]} و${chunk(rem)}` : hundreds[h];
  };

  const intPart = Math.floor(n);
  const decPart = Math.round((n - intPart) * 100);

  let result = "";
  if (intPart >= 1000000) {
    const m = Math.floor(intPart / 1000000);
    result += chunk(m) + " مليون ";
  }
  const rem = intPart % 1000000;
  if (rem >= 1000) {
    const k = Math.floor(rem / 1000);
    if (k === 1) result += "ألف ";
    else if (k === 2) result += "ألفان ";
    else if (k < 11) result += chunk(k) + " آلاف ";
    else result += chunk(k) + " ألف ";
    const r = rem % 1000;
    if (r) result += "و" + chunk(r);
  } else if (rem > 0) {
    result += chunk(rem);
  }

  if (decPart > 0) {
    result += ` و ${chunk(decPart)} هللة`;
  }
  return result.trim() || "صفر";
}

export function numberToWordsEn(n: number): string {
  if (n === 0) return "zero";
  const ones = [
    "",
    "one",
    "two",
    "three",
    "four",
    "five",
    "six",
    "seven",
    "eight",
    "nine",
    "ten",
    "eleven",
    "twelve",
    "thirteen",
    "fourteen",
    "fifteen",
    "sixteen",
    "seventeen",
    "eighteen",
    "nineteen",
  ];
  const tens = [
    "",
    "",
    "twenty",
    "thirty",
    "forty",
    "fifty",
    "sixty",
    "seventy",
    "eighty",
    "ninety",
  ];
  const chunk = (num: number): string => {
    if (num < 20) return ones[num];
    if (num < 100) {
      const t = Math.floor(num / 10);
      const o = num % 10;
      return o ? `${tens[t]}-${ones[o]}` : tens[t];
    }
    const h = Math.floor(num / 100);
    const rem = num % 100;
    return rem ? `${ones[h]} hundred ${chunk(rem)}` : `${ones[h]} hundred`;
  };
  const intPart = Math.floor(n);
  const decPart = Math.round((n - intPart) * 100);
  let result = "";
  if (intPart >= 1000000) {
    result += chunk(Math.floor(intPart / 1000000)) + " million ";
  }
  const rem = intPart % 1000000;
  if (rem >= 1000) {
    result += chunk(Math.floor(rem / 1000)) + " thousand ";
    const r = rem % 1000;
    if (r) result += chunk(r);
  } else if (rem > 0) {
    result += chunk(rem);
  }
  if (decPart > 0) result += ` and ${chunk(decPart)} cents`;
  return result.trim();
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)+/g, "");
}

export function generateReceiptNumber(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  const r = Math.floor(Math.random() * 9000 + 1000);
  return `RCP-${y}${m}${d}-${r}`;
}
