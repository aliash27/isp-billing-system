import { SignJWT, jwtVerify } from "jose";
import bcrypt from "bcryptjs";
import { cookies } from "next/headers";
import { db } from "@/db";
import { users, tenants } from "@/db/schema";
import { eq } from "drizzle-orm";

export type SessionUser = {
  id: string;
  tenantId: string | null;
  role: "super_admin" | "admin" | "accountant";
  fullName: string;
  email: string;
  status: string;
  tenantStatus?: string | null;
  tenantName?: string | null;
  readMode?: boolean | null;
};

const SESSION_COOKIE = "isp_session";
const JWT_SECRET_BYTES = new TextEncoder().encode(
  process.env.JWT_SECRET || "dev-secret-change-me-in-production-32bytes!"
);

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(
  password: string,
  hash: string
): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export async function signSession(payload: SessionUser): Promise<string> {
  return new SignJWT(payload as unknown as Record<string, unknown>)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(JWT_SECRET_BYTES);
}

export async function verifySession(
  token: string
): Promise<SessionUser | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET_BYTES);
    return payload as unknown as SessionUser;
  } catch {
    return null;
  }
}

export async function setSessionCookie(token: string) {
  const c = await cookies();
  c.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function clearSessionCookie() {
  const c = await cookies();
  c.delete(SESSION_COOKIE);
}

export async function getSession(): Promise<SessionUser | null> {
  const c = await cookies();
  const token = c.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  return verifySession(token);
}

export async function requireSession(): Promise<SessionUser> {
  const session = await getSession();
  if (!session) {
    throw new Error("UNAUTHORIZED");
  }
  return session;
}

export async function signIn(
  email: string,
  password: string
): Promise<{ user: SessionUser; token: string } | { error: string }> {
  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.email, email.toLowerCase().trim()))
    .limit(1);

  if (!user) return { error: "invalid" };
  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) return { error: "invalid" };
  if (user.status !== "active") return { error: "locked" };

  let tenantStatus: string | null = null;
  let tenantName: string | null = null;
  let readMode = false;
  if (user.tenantId) {
    const [tenant] = await db
      .select({
        status: tenants.status,
        name: tenants.name,
        readMode: tenants.readMode,
      })
      .from(tenants)
      .where(eq(tenants.id, user.tenantId))
      .limit(1);
    tenantStatus = tenant?.status ?? null;
    tenantName = tenant?.name ?? null;
    readMode = tenant?.readMode ?? false;
    // Expired or suspended tenant => block normal access
    if (tenant && (tenant.status === "suspended" || tenant.status === "expired")) {
      if (user.role !== "super_admin") {
        return { error: "locked" };
      }
    }
  }

  const sessionUser: SessionUser = {
    id: user.id,
    tenantId: user.tenantId,
    role: user.role,
    fullName: user.fullName,
    email: user.email,
    status: user.status,
    tenantStatus,
    tenantName,
    readMode,
  };

  // update last login
  try {
    await db
      .update(users)
      .set({ lastLoginAt: new Date() })
      .where(eq(users.id, user.id));
  } catch {
    /* ignore */
  }

  const token = await signSession(sessionUser);
  return { user: sessionUser, token };
}

export function requireRole(
  session: SessionUser,
  roles: Array<SessionUser["role"]>
) {
  if (!roles.includes(session.role)) {
    throw new Error("FORBIDDEN");
  }
}

export function requireTenant(session: SessionUser): string {
  if (session.role === "super_admin") {
    throw new Error("SUPER_ADMIN_NO_TENANT");
  }
  if (!session.tenantId) {
    throw new Error("NO_TENANT");
  }
  return session.tenantId;
}
