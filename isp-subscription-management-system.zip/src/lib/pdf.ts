"use client";
import jsPDF from "jspdf";
import type { Lang } from "./i18n";
import { formatMoney, numberToWordsAr, numberToWordsEn } from "./utils";

export type ReceiptData = {
  receiptNumber: string;
  date: string;
  company: {
    name: string;
    phone?: string | null;
    address?: string | null;
    logoUrl?: string | null;
  };
  customer: {
    fullName: string;
    phone?: string | null;
    address?: string | null;
  };
  amount: number;
  currency?: string;
  method: string;
  type: string;
  monthsCovered: number;
  note?: string | null;
  lang: Lang;
  accentColor?: string;
  footerText?: string | null;
  thankYouMessage?: string | null;
};

export async function generateReceiptPDF(data: ReceiptData): Promise<Blob> {
  const isAr = data.lang === "ar";
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a5",
  });

  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const accent = data.accentColor || "#0ea5e9";
  const [r, g, b] = hexToRgb(accent);

  // Accent bar
  doc.setFillColor(r, g, b);
  doc.rect(0, 0, W, 10, "F");

  // Logo placeholder circle
  doc.setFillColor(r, g, b);
  doc.circle(W / 2, 28, 10, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(12);
  doc.text((data.company.name || "ISP").slice(0, 2).toUpperCase(), W / 2, 30, {
    align: "center",
  });

  // Company name
  doc.setTextColor(30, 30, 30);
  doc.setFontSize(14);
  doc.text(data.company.name || "ISP", W / 2, 46, { align: "center" });

  // Title
  doc.setTextColor(r, g, b);
  doc.setFontSize(16);
  doc.text(isAr ? "إيصال قبض" : "RECEIPT", W / 2, 56, { align: "center" });

  // Receipt number + date row
  doc.setTextColor(80, 80, 80);
  doc.setFontSize(9);
  const leftLabel = isAr ? "رقم الإيصال" : "Receipt No.";
  const rightLabel = isAr ? "التاريخ" : "Date";
  doc.text(`${leftLabel}: ${data.receiptNumber}`, 14, 68);
  doc.text(`${rightLabel}: ${data.date}`, W - 14, 68, { align: "right" });

  // Divider
  doc.setDrawColor(220, 220, 220);
  doc.line(14, 72, W - 14, 72);

  // Customer box
  doc.setFillColor(245, 247, 250);
  doc.roundedRect(14, 78, W - 28, 24, 2, 2, "F");
  doc.setTextColor(100, 100, 100);
  doc.setFontSize(9);
  doc.text(isAr ? "استلمنا من" : "Received from", 18, 84);
  doc.setTextColor(20, 20, 20);
  doc.setFontSize(12);
  doc.text(data.customer.fullName, 18, 92);
  if (data.customer.phone) {
    doc.setFontSize(9);
    doc.setTextColor(100, 100, 100);
    doc.text(data.customer.phone, 18, 99);
  }

  // Amount box
  doc.setFillColor(r, g, b);
  doc.roundedRect(14, 108, W - 28, 22, 2, 2, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(9);
  doc.text(isAr ? "المبلغ المدفوع" : "Amount Paid", 18, 114);
  doc.setFontSize(16);
  doc.text(
    formatMoney(data.amount, data.currency || "SAR", data.lang),
    W - 18,
    122,
    { align: "right" }
  );

  // Amount in words
  doc.setTextColor(60, 60, 60);
  doc.setFontSize(9);
  const wordsLabel = isAr ? "المبلغ كتابة" : "Amount in words";
  doc.text(`${wordsLabel}:`, 14, 140);
  const words = isAr
    ? numberToWordsAr(data.amount)
    : numberToWordsEn(data.amount);
  doc.setFontSize(10);
  const wordLines = doc.splitTextToSize(words, W - 28);
  doc.text(wordLines, 14, 146);

  // Details table
  const detailsY = 146 + wordLines.length * 5 + 6;
  doc.setDrawColor(220, 220, 220);
  doc.setFillColor(250, 250, 250);
  doc.rect(14, detailsY, W - 28, 6, "F");
  doc.setTextColor(80, 80, 80);
  doc.setFontSize(9);
  doc.text(isAr ? "البيان" : "Description", 18, detailsY + 4);
  doc.text(isAr ? "القيمة" : "Value", W - 18, detailsY + 4, {
    align: "right",
  });

  const rows = [
    [isAr ? "طريقة الدفع" : "Method", data.method],
    [isAr ? "النوع" : "Type", data.type],
    [
      isAr ? "الأشهر المشمولة" : "Months Covered",
      String(data.monthsCovered),
    ],
  ];
  if (data.note) rows.push([isAr ? "ملاحظات" : "Note", data.note]);

  let rowY = detailsY + 6;
  doc.setTextColor(30, 30, 30);
  rows.forEach(([label, value]) => {
    doc.text(label, 18, rowY + 5);
    doc.text(value, W - 18, rowY + 5, { align: "right" });
    rowY += 7;
    doc.setDrawColor(240, 240, 240);
    doc.line(14, rowY, W - 14, rowY);
  });

  // Footer
  doc.setTextColor(120, 120, 120);
  doc.setFontSize(8);
  if (data.company.phone) {
    doc.text(
      `${isAr ? "هاتف" : "Phone"}: ${data.company.phone}`,
      W / 2,
      H - 20,
      { align: "center" }
    );
  }
  if (data.company.address) {
    doc.text(data.company.address, W / 2, H - 16, { align: "center" });
  }
  const thankYou =
    data.thankYouMessage ||
    (isAr ? "شكراً لتعاملكم معنا" : "Thank you for your business");
  doc.setTextColor(r, g, b);
  doc.setFontSize(10);
  doc.text(thankYou, W / 2, H - 10, { align: "center" });

  if (data.footerText) {
    doc.setTextColor(140, 140, 140);
    doc.setFontSize(7);
    doc.text(data.footerText, W / 2, H - 5, { align: "center" });
  }

  return doc.output("blob");
}

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  const bigint = parseInt(
    h.length === 3
      ? h
          .split("")
          .map((c) => c + c)
          .join("")
      : h,
    16
  );
  return [(bigint >> 16) & 255, (bigint >> 8) & 255, bigint & 255];
}

export async function printReceiptHTML(data: ReceiptData) {
  const isAr = data.lang === "ar";
  const accent = data.accentColor || "#0ea5e9";
  const html = `
<!DOCTYPE html>
<html lang="${data.lang}" dir="${isAr ? "rtl" : "ltr"}">
<head>
<meta charset="UTF-8" />
<title>${data.receiptNumber}</title>
<style>
  @page { size: A5; margin: 8mm; }
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI', Tahoma, Arial, sans-serif; color: #1e293b; margin: 0; padding: 16px; }
  .header { text-align: center; border-bottom: 3px solid ${accent}; padding-bottom: 12px; margin-bottom: 16px; }
  .header h1 { margin: 0; color: ${accent}; font-size: 22px; }
  .header h2 { margin: 4px 0 0; font-size: 16px; color: #334155; }
  .meta { display: flex; justify-content: space-between; font-size: 12px; color: #64748b; margin-bottom: 16px; }
  .customer { background: #f1f5f9; padding: 12px; border-radius: 8px; margin-bottom: 16px; }
  .customer .label { font-size: 11px; color: #64748b; }
  .customer .name { font-size: 16px; font-weight: 600; }
  .amount { background: ${accent}; color: white; padding: 14px; border-radius: 8px; text-align: center; margin-bottom: 16px; }
  .amount .label { font-size: 12px; opacity: 0.9; }
  .amount .value { font-size: 22px; font-weight: 700; margin-top: 4px; }
  .words { font-size: 12px; color: #475569; margin-bottom: 16px; font-style: italic; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 13px; }
  th, td { padding: 8px 10px; text-align: ${isAr ? "right" : "left"}; border-bottom: 1px solid #e2e8f0; }
  th { background: #f8fafc; color: #64748b; font-weight: 500; }
  td:last-child, th:last-child { text-align: ${isAr ? "left" : "right"}; }
  .footer { text-align: center; margin-top: 20px; padding-top: 12px; border-top: 1px solid #e2e8f0; font-size: 11px; color: #94a3b8; }
  .thank { color: ${accent}; font-size: 14px; font-weight: 600; margin: 12px 0 6px; }
  @media print {
    body { padding: 0; }
  }
</style>
</head>
<body>
  <div class="header">
    <h1>${data.company.name}</h1>
    ${data.company.phone ? `<div style="font-size:12px;color:#64748b">${data.company.phone}</div>` : ""}
    ${data.company.address ? `<div style="font-size:11px;color:#94a3b8">${data.company.address}</div>` : ""}
    <h2>${isAr ? "إيصال قبض" : "Receipt"}</h2>
  </div>
  <div class="meta">
    <span><strong>${isAr ? "رقم الإيصال" : "Receipt No."}:</strong> ${data.receiptNumber}</span>
    <span><strong>${isAr ? "التاريخ" : "Date"}:</strong> ${data.date}</span>
  </div>
  <div class="customer">
    <div class="label">${isAr ? "استلمنا من" : "Received from"}</div>
    <div class="name">${data.customer.fullName}</div>
    ${data.customer.phone ? `<div style="font-size:12px;color:#64748b">${data.customer.phone}</div>` : ""}
  </div>
  <div class="amount">
    <div class="label">${isAr ? "المبلغ المدفوع" : "Amount Paid"}</div>
    <div class="value">${formatMoney(data.amount, data.currency || "SAR", data.lang)}</div>
  </div>
  <div class="words">
    <strong>${isAr ? "المبلغ كتابة" : "Amount in words"}:</strong>
    ${isAr ? numberToWordsAr(data.amount) : numberToWordsEn(data.amount)}
  </div>
  <table>
    <tr><th>${isAr ? "طريقة الدفع" : "Method"}</th><td>${data.method}</td></tr>
    <tr><th>${isAr ? "النوع" : "Type"}</th><td>${data.type}</td></tr>
    <tr><th>${isAr ? "الأشهر المشمولة" : "Months"}</th><td>${data.monthsCovered}</td></tr>
    ${data.note ? `<tr><th>${isAr ? "ملاحظات" : "Note"}</th><td>${data.note}</td></tr>` : ""}
  </table>
  <div class="thank">${data.thankYouMessage || (isAr ? "شكراً لتعاملكم معنا" : "Thank you for your business")}</div>
  <div class="footer">${data.footerText || ""}</div>
</body>
</html>`;
  const w = window.open("", "_blank", "width=700,height=900");
  if (!w) return;
  w.document.write(html);
  w.document.close();
  setTimeout(() => w.print(), 300);
}
