"use client";

import { useApp } from "@/components/providers";
import {
  Building2,
  Calendar,
  Power,
  RefreshCw,
} from "lucide-react";
import { useState } from "react";
import {
  renewTenant,
  updateTenantStatus,
  type listAllTenants,
} from "@/app/super-admin/actions";
import { formatDate } from "@/lib/utils";
import { useRouter } from "next/navigation";

export function TenantsView({
  rows,
}: {
  rows: Awaited<ReturnType<typeof listAllTenants>>;
}) {
  const { t, lang } = useApp();
  const router = useRouter();

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-bold">{t("superAdmin.tenants")}</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {rows.map((tenant) => (
          <TenantCard
            key={tenant.id}
            tenant={tenant}
            onAction={() => router.refresh()}
          />
        ))}
      </div>
    </div>
  );
}

function TenantCard({
  tenant,
  onAction,
}: {
  tenant: Awaited<ReturnType<typeof listAllTenants>>[number];
  onAction: () => void;
}) {
  const { t, lang } = useApp();

  const onStatus = async (status: "active" | "suspended" | "expired") => {
    if (!confirm(`${lang === "ar" ? "تأكيد" : "Confirm"}: ${status}?`)) return;
    await updateTenantStatus(tenant.id, status);
    onAction();
  };

  const onRenew = async (planCode: string) => {
    await renewTenant(tenant.id, planCode);
    onAction();
  };

  return (
    <div className="card p-5">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-white font-bold text-lg">
            {tenant.name.charAt(0)}
          </div>
          <div className="min-w-0">
            <div className="font-bold truncate">{tenant.name}</div>
            <div className="text-xs text-[var(--text-muted)] truncate">
              {tenant.email}
            </div>
          </div>
        </div>
        <span
          className={`badge ${
            tenant.status === "active"
              ? "badge-success"
              : tenant.status === "trial"
                ? "badge-info"
                : tenant.status === "suspended"
                  ? "badge-warning"
                  : "badge-danger"
          }`}
        >
          {t(`statuses.${tenant.status}` as "statuses.active")}
        </span>
      </div>

      <div className="space-y-1.5 text-xs text-[var(--text-muted)] mb-4">
        <div className="flex items-center gap-2">
          <Calendar className="w-3 h-3" />
          {lang === "ar" ? "منتهي في" : "Expires"}:{" "}
          {tenant.subscriptionEndsAt
            ? formatDate(tenant.subscriptionEndsAt, lang)
            : "—"}
        </div>
        {tenant.phone && <div>📞 {tenant.phone}</div>}
        <div className="font-mono">/{tenant.slug}</div>
      </div>

      <div className="grid grid-cols-3 gap-1.5 pt-3 border-t border-[var(--border)]">
        <button
          onClick={() => onStatus("active")}
          className="btn btn-success !py-1.5 !px-2 text-xs"
          title="Activate"
        >
          <Power className="w-3 h-3" />
        </button>
        <button
          onClick={() => onStatus("suspended")}
          className="btn !py-1.5 !px-2 text-xs"
          style={{ background: "var(--warning)", color: "white" }}
        >
          ⏸
        </button>
        <button
          onClick={() => onRenew("monthly")}
          className="btn btn-primary !py-1.5 !px-2 text-xs"
          title="Renew"
        >
          <RefreshCw className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
}
