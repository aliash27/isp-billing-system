"use client";

import { useApp } from "@/components/providers";
import {
  Plus,
  Search,
  Receipt,
  Trash2,
  Download,
  Printer,
} from "lucide-react";
import { useState, useTransition, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createPayment, deletePayment, type listPayments } from "@/app/actions";
import { cn, formatMoney, formatDate } from "@/lib/utils";
import { generateReceiptPDF } from "@/lib/pdf";
import type { Subscriber } from "@/db/schema";

type PaymentRow = Awaited<ReturnType<typeof listPayments>>["rows"][number];

export function PaymentsView({
  initial,
  subscribers,
  searchParams,
}: {
  initial: Awaited<ReturnType<typeof listPayments>>;
  subscribers: Subscriber[];
  searchParams: { q?: string; from?: string; to?: string; page?: string };
}) {
  const { t, lang } = useApp();
  const router = useRouter();
  const sp = useSearchParams();

  const [rows, setRows] = useState(initial.rows);
  const [page, setPage] = useState(initial.page);
  const [pages, setPages] = useState(initial.pages);
  const [total, setTotal] = useState(initial.total);
  const [showForm, setShowForm] = useState(false);

  const refresh = () => {
    const params = new URLSearchParams(sp.toString());
    router.push(`/dashboard/payments?${params.toString()}`);
    router.refresh();
  };

  useEffect(() => {
    setRows(initial.rows);
    setPage(initial.page);
    setPages(initial.pages);
    setTotal(initial.total);
  }, [initial]);

  const onSearch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const params = new URLSearchParams();
    const q = String(fd.get("q") || "");
    const from = String(fd.get("from") || "");
    const to = String(fd.get("to") || "");
    if (q) params.set("q", q);
    if (from) params.set("from", from);
    if (to) params.set("to", to);
    router.push(`/dashboard/payments?${params.toString()}`);
  };

  const onDelete = async (id: string) => {
    if (!confirm(t("messages.confirmDelete"))) return;
    await deletePayment(id);
    refresh();
  };

  const downloadPDF = async (receiptNumber: string) => {
    const res = await fetch(`/api/receipts/${receiptNumber}`);
    const data = await res.json();
    if (!data.ok) return alert("Error");
    const { payment, subscriber, tenant, template } = data.data;
    const blob = await generateReceiptPDF({
      receiptNumber: payment.receiptNumber,
      date: formatDate(payment.paidAt, lang),
      company: {
        name: tenant.name,
        phone: tenant.phone,
        address: tenant.address,
      },
      customer: {
        fullName: subscriber.fullName,
        phone: subscriber.phone,
        address: subscriber.address,
      },
      amount: parseFloat(payment.amount),
      currency: tenant.currency || "SAR",
      method: t(`payments.${payment.method}`),
      type: t(`payments.${payment.type}`),
      monthsCovered: parseFloat(payment.monthsCovered),
      note: payment.note,
      lang,
      accentColor: template?.accentColor,
      footerText: template?.footerText,
      thankYouMessage: template?.thankYouMessage,
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${payment.receiptNumber}.pdf`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const printReceipt = (receiptNumber: string) => {
    window.open(`/dashboard/receipts/${receiptNumber}/print`, "_blank");
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">{t("payments.title")}</h1>
          <p className="text-sm text-[var(--text-muted)]">
            {total} {lang === "ar" ? "دفعة" : "payments"}
          </p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="btn btn-primary"
        >
          <Plus className="w-4 h-4" />
          {t("payments.addNew")}
        </button>
      </div>

      <form onSubmit={onSearch} className="card p-4 grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="relative md:col-span-2">
          <Search className="absolute top-1/2 -translate-y-1/2 start-3 w-4 h-4 text-[var(--text-muted)]" />
          <input
            name="q"
            defaultValue={searchParams.q}
            className="input ps-10"
            placeholder={t("common.search") + "..."}
          />
        </div>
        <input
          type="date"
          name="from"
          defaultValue={searchParams.from}
          className="input"
        />
        <input
          type="date"
          name="to"
          defaultValue={searchParams.to}
          className="input"
        />
        <button type="submit" className="btn btn-ghost md:col-span-4">
          {t("common.filter")}
        </button>
      </form>

      <div className="table-wrap">
        <div className="overflow-x-auto">
          <table>
            <thead>
              <tr>
                <th>{t("payments.receiptNumber")}</th>
                <th>{t("receipts.customer")}</th>
                <th>{t("payments.amount")}</th>
                <th>{t("payments.method")}</th>
                <th>{t("payments.type")}</th>
                <th>{t("payments.paidAt")}</th>
                <th>{t("common.actions")}</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-[var(--text-muted)]">
                    {t("common.noData")}
                  </td>
                </tr>
              ) : (
                rows.map(({ payment, subscriber }) => (
                  <tr key={payment.id}>
                    <td>
                      <div className="flex items-center gap-2">
                        <Receipt className="w-4 h-4 text-[var(--primary)]" />
                        <span className="font-mono text-xs">{payment.receiptNumber}</span>
                      </div>
                    </td>
                    <td className="font-medium">{subscriber.fullName}</td>
                    <td className="font-semibold text-[var(--success)]">
                      {formatMoney(payment.amount, "SAR", lang)}
                    </td>
                    <td>
                      <span className="badge badge-info">
                        {t(`payments.${payment.method}`)}
                      </span>
                    </td>
                    <td>
                      <span className="badge badge-muted">
                        {t(`payments.${payment.type}`)}
                      </span>
                    </td>
                    <td className="text-xs">{formatDate(payment.paidAt, lang)}</td>
                    <td>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => printReceipt(payment.receiptNumber)}
                          className="p-2 rounded-lg hover:bg-[var(--bg-muted)]"
                          title={t("receipts.print")}
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => downloadPDF(payment.receiptNumber)}
                          className="p-2 rounded-lg hover:bg-[var(--bg-muted)]"
                          title={t("receipts.download")}
                        >
                          <Download className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onDelete(payment.id)}
                          className="p-2 rounded-lg hover:bg-[color-mix(in_srgb,var(--danger)_15%,transparent)] text-[var(--danger)]"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {pages > 1 && (
        <div className="flex items-center justify-center gap-2">
          {Array.from({ length: pages }, (_, i) => i + 1).map((p) => (
            <button
              key={p}
              onClick={() => {
                const params = new URLSearchParams(sp.toString());
                params.set("page", String(p));
                router.push(`/dashboard/payments?${params.toString()}`);
              }}
              className={cn(
                "btn !p-2 min-w-[40px]",
                p === page ? "btn-primary" : "btn-ghost"
              )}
            >
              {p}
            </button>
          ))}
        </div>
      )}

      {showForm && (
        <PaymentForm
          subscribers={subscribers}
          onClose={() => setShowForm(false)}
          onSaved={() => {
            setShowForm(false);
            refresh();
          }}
        />
      )}
    </div>
  );
}

function PaymentForm({
  subscribers,
  onClose,
  onSaved,
}: {
  subscribers: Subscriber[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const { t } = useApp();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    const fd = new FormData(e.currentTarget);
    try {
      await createPayment({
        subscriberId: String(fd.get("subscriberId")),
        amount: String(fd.get("amount")),
        method: fd.get("method") as "cash",
        type: fd.get("type") as "subscription",
        monthsCovered: String(fd.get("monthsCovered") || "1"),
        note: String(fd.get("note") || ""),
      });
      onSaved();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 modal-overlay flex items-center justify-center p-4">
      <div className="card w-full max-w-lg">
        <div className="p-5 border-b border-[var(--border)] flex items-center justify-between">
          <h2 className="text-lg font-bold">{t("payments.addNew")}</h2>
          <button
            onClick={onClose}
            className="p-2 rounded hover:bg-[var(--bg-muted)]"
          >
            ✕
          </button>
        </div>
        <form onSubmit={onSubmit} className="p-5 space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1.5">
              {t("receipts.customer")} *
            </label>
            <select name="subscriberId" className="input" required>
              <option value="">—</option>
              {subscribers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.fullName} {s.phone ? `(${s.phone})` : ""}
                </option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium mb-1.5">
                {t("payments.amount")} *
              </label>
              <input
                name="amount"
                type="number"
                step="0.01"
                className="input"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">
                {t("payments.monthsCovered")}
              </label>
              <input
                name="monthsCovered"
                type="number"
                step="0.5"
                defaultValue="1"
                className="input"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium mb-1.5">
                {t("payments.method")}
              </label>
              <select name="method" className="input" defaultValue="cash">
                <option value="cash">{t("payments.cash")}</option>
                <option value="card">{t("payments.card")}</option>
                <option value="transfer">{t("payments.transfer")}</option>
                <option value="check">{t("payments.check")}</option>
                <option value="other">{t("payments.other")}</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">
                {t("payments.type")}
              </label>
              <select name="type" className="input" defaultValue="subscription">
                <option value="subscription">{t("payments.subscription")}</option>
                <option value="debt">{t("payments.debt")}</option>
                <option value="advance">{t("payments.advance")}</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">
              {t("common.notes")}
            </label>
            <textarea name="note" className="input" rows={2} />
          </div>
          {error && (
            <div className="bg-[color-mix(in_srgb,var(--danger)_10%,transparent)] text-[var(--danger)] rounded-lg p-3 text-sm">
              {error}
            </div>
          )}
          <div className="flex justify-end gap-2 pt-4 border-t border-[var(--border)]">
            <button type="button" onClick={onClose} className="btn btn-ghost">
              {t("common.cancel")}
            </button>
            <button type="submit" disabled={loading} className="btn btn-primary">
              {loading ? t("common.loading") : t("common.save")}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
