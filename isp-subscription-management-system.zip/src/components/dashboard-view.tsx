"use client";

import { useApp } from "@/components/providers";
import {
  Users,
  UserCheck,
  UserX,
  Wallet,
  TrendingUp,
  Receipt,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Clock,
} from "lucide-react";
import { formatMoney, formatDate } from "@/lib/utils";
import type { SessionUser } from "@/lib/auth";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  CartesianGrid,
} from "recharts";

type Props = {
  data: Awaited<ReturnType<typeof import("@/app/actions").getDashboardStats>>;
  session: SessionUser;
};

export function DashboardView({ data, session }: Props) {
  const { t, lang } = useApp();
  const { stats, recentPayments, revenueByMonth, subscriptionBreakdown, expiringSoon } = data;

  const cards = [
    {
      title: t("dashboard.totalSubscribers"),
      value: stats.total,
      icon: Users,
      color: "from-sky-500 to-blue-600",
      trend: null,
    },
    {
      title: t("dashboard.activeSubscribers"),
      value: stats.active,
      icon: UserCheck,
      color: "from-emerald-500 to-teal-600",
      trend: { up: true, value: "+12%" },
    },
    {
      title: t("dashboard.expiredSubscribers"),
      value: stats.expired,
      icon: UserX,
      color: "from-rose-500 to-pink-600",
      trend: stats.expired > 0 ? { up: false, value: String(stats.expired) } : null,
    },
    {
      title: t("dashboard.totalDebts"),
      value: formatMoney(stats.totalDebt, session.tenantName ? "SAR" : "SAR", lang),
      icon: Wallet,
      color: "from-amber-500 to-orange-600",
      trend: null,
    },
    {
      title: t("dashboard.monthlyRevenue"),
      value: formatMoney(stats.monthlyRevenue, "SAR", lang),
      icon: TrendingUp,
      color: "from-violet-500 to-purple-600",
      trend: { up: true, value: `${stats.monthlyCount} ${lang === "ar" ? "دفعة" : "payments"}` },
    },
  ];

  const typeColors: Record<string, string> = {
    monthly: "#0ea5e9",
    quarterly: "#8b5cf6",
    semi_annual: "#f59e0b",
    annual: "#10b981",
  };

  const pieData = subscriptionBreakdown.map((b) => ({
    name: t(`subscribers.${b.type}`),
    value: b.count,
    color: typeColors[b.type] || "#64748b",
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">
            {t("dashboard.welcome")}, {session.fullName.split(" ")[0]} 👋
          </h1>
          <p className="text-[var(--text-muted)] mt-1">
            {t("dashboard.title")} · {formatDate(new Date(), lang)}
          </p>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <div key={c.title} className="card p-5 slide-in">
              <div className="flex items-start justify-between mb-3">
                <div
                  className={`w-11 h-11 rounded-xl bg-gradient-to-br ${c.color} flex items-center justify-center text-white shadow-lg`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                {c.trend && (
                  <span
                    className={`badge ${c.trend.up ? "badge-success" : "badge-danger"}`}
                  >
                    {c.trend.up ? (
                      <ArrowUpRight className="w-3 h-3" />
                    ) : (
                      <ArrowDownRight className="w-3 h-3" />
                    )}
                    {c.trend.value}
                  </span>
                )}
              </div>
              <div className="text-2xl font-bold">{c.value}</div>
              <div className="text-xs text-[var(--text-muted)] mt-1">
                {c.title}
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-lg">{t("dashboard.revenueChart")}</h3>
            <span className="badge badge-info">
              <Calendar className="w-3 h-3" />
              6 {t("common.month")}
            </span>
          </div>
          <div style={{ width: "100%", height: 280 }}>
            <ResponsiveContainer>
              <BarChart data={revenueByMonth}>
                <defs>
                  <linearGradient id="bar" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#0ea5e9" />
                    <stop offset="100%" stopColor="#6366f1" />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="month" stroke="var(--text-muted)" fontSize={12} />
                <YAxis stroke="var(--text-muted)" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    background: "var(--card)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    color: "var(--text)",
                  }}
                />
                <Bar dataKey="revenue" fill="url(#bar)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card p-5">
          <h3 className="font-semibold text-lg mb-4">
            {t("dashboard.subscriptionBreakdown")}
          </h3>
          {pieData.length === 0 ? (
            <div className="h-64 flex items-center justify-center text-[var(--text-muted)]">
              {t("common.noData")}
            </div>
          ) : (
            <div style={{ width: "100%", height: 260 }}>
              <ResponsiveContainer>
                <PieChart>
                  <Pie
                    data={pieData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={90}
                    innerRadius={50}
                    paddingAngle={2}
                  >
                    {pieData.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      background: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: 8,
                      color: "var(--text)",
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Receipt className="w-5 h-5" />
              {t("dashboard.recentPayments")}
            </h3>
            <a
              href="/dashboard/payments"
              className="text-xs text-[var(--primary)] hover:underline"
            >
              {t("common.view")} →
            </a>
          </div>
          {recentPayments.length === 0 ? (
            <div className="text-center py-12 text-[var(--text-muted)]">
              {t("common.noData")}
            </div>
          ) : (
            <div className="space-y-2">
              {recentPayments.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-[var(--bg-muted)] transition"
                >
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white font-semibold text-sm">
                    {p.subscriberName.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm truncate">
                      {p.subscriberName}
                    </div>
                    <div className="text-xs text-[var(--text-muted)]">
                      {p.receiptNumber} · {formatDate(p.paidAt, lang)}
                    </div>
                  </div>
                  <div className="text-end">
                    <div className="font-semibold text-[var(--success)]">
                      +{formatMoney(p.amount, "SAR", lang)}
                    </div>
                    <span className="badge badge-muted text-[10px]">
                      {t(`payments.${p.method}`)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Clock className="w-5 h-5 text-[var(--warning)]" />
              {t("dashboard.expiringSoon")}
            </h3>
          </div>
          {expiringSoon.length === 0 ? (
            <div className="text-center py-12 text-[var(--text-muted)]">
              {t("common.noData")}
            </div>
          ) : (
            <div className="space-y-2">
              {expiringSoon.map((s) => (
                <div
                  key={s.id}
                  className="flex items-center gap-3 p-3 rounded-lg border border-[color-mix(in_srgb,var(--warning)_30%,transparent)] bg-[color-mix(in_srgb,var(--warning)_5%,transparent)]"
                >
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-white font-semibold text-sm">
                    {s.fullName.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm truncate">
                      {s.fullName}
                    </div>
                    <div className="text-xs text-[var(--text-muted)]">
                      {s.phone || "—"}
                    </div>
                  </div>
                  <div className="text-xs font-medium">
                    {formatDate(s.nextBillingAt, lang)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
