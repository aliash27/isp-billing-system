"use client";

import { useApp } from "@/components/providers";
import { ScrollText } from "lucide-react";
import { formatDate } from "@/lib/utils";
import type { listAuditLogs } from "@/app/super-admin/actions";

export function AuditView({
  rows,
}: {
  rows: Awaited<ReturnType<typeof listAuditLogs>>;
}) {
  const { t, lang } = useApp();

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-bold">{t("nav.audit")}</h1>

      <div className="table-wrap">
        <div className="overflow-x-auto">
          <table>
            <thead>
              <tr>
                <th>{t("common.date")}</th>
                <th>{lang === "ar" ? "المستخدم" : "User"}</th>
                <th>{lang === "ar" ? "الإجراء" : "Action"}</th>
                <th>{lang === "ar" ? "الكيان" : "Entity"}</th>
                <th>ID</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={5} className="text-center py-12 text-[var(--text-muted)]">
                    {t("common.noData")}
                  </td>
                </tr>
              ) : (
                rows.map((r) => (
                  <tr key={r.id}>
                    <td className="text-xs">{formatDate(r.createdAt, lang)}</td>
                    <td className="font-medium text-sm">{r.actorName || "—"}</td>
                    <td>
                      <span className="badge badge-info">{r.action}</span>
                    </td>
                    <td className="font-mono text-xs">{r.entity}</td>
                    <td className="font-mono text-xs text-[var(--text-muted)] truncate max-w-[150px]">
                      {r.entityId?.slice(0, 8) || "—"}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
