"use client";

import { useApp } from "@/components/providers";
import {
  ArrowLeft,
  Phone,
  MapPin,
  Calendar,
  Wallet,
  CreditCard,
  Receipt,
} from "lucide-react";
import Link from "next/link";
import { formatMoney, formatDate } from "@/lib/utils";
import type { getSubscriber } from "@/app/actions";

type Data = NonNullable<Awaited<ReturnType<typeof getSubscriber>>>;

export function SubscriberDetail({ data }: { data: Data }) {
  const { t, lang } = useApp();
  const { subscriber, payments, debts } = data;

  return (
    <div className="space-y-5">
      <div>
        <Link
          href="/dashboard/subscribers"
          className="inline-flex items-center gap-2 text-sm text-[var(--text-muted)] hover:text-[var(--text)] mb-3"
        >
          <ArrowLeft className="w-4 h-4" />
          {t("common.back")}
        </Link>
        <h1 className="text-2xl font-bold">{subscriber.fullName}</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="card p-6 lg:col-span-1 space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-primary flex items-center justify-center text-white font-bold text-2xl">
              {subscriber.fullName.charAt(0)}
            </div>
            <div>
              <div className="font-bold text-lg">{subscriber.fullName}</div>
              <span
                className={`badge ${
                  subscriber.status === "active"
                    ? "badge-success"
                    : subscriber.status === "expired"
                      ? "badge-danger"
                      : "badge-warning"
                }`}
              >
                {t(`subscribers.${subscriber.status}`)}
              </span>
            </div>
          </div>

          <div className="space-y-3 text-sm">
            <Row icon={Phone} label={t("subscribers.phone")} value={subscriber.phone || "—"} />
            <Row icon={MapPin} label={t("common.address")} value={subscriber.address || "—"} />
            <Row icon={MapPin} label={t("subscribers.area")} value={subscriber.area || "—"} />
            <Row
              icon={Calendar}
              label={t("subscribers.nextBilling")}
              value={formatDate(subscriber.nextBillingAt, lang)}
            />
          </div>

          <div className="pt-4 border-t border-[var(--border)] grid grid-cols-2 gap-3">
            <InfoBox label={t("subscribers.monthlyFee")} value={formatMoney(subscriber.monthlyFee, "SAR", lang)} />
            <InfoBox
              label={t("subscribers.debtAmount")}
              value={formatMoney(subscriber.debtAmount, "SAR", lang)}
              danger={parseFloat(subscriber.debtAmount) > 0}
            />
          </div>

          <div className="pt-4 border-t border-[var(--border)] text-xs">
            <span className="badge badge-info">
              {t(`subscribers.${subscriber.subscriptionType}`)}
            </span>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-5">
          <div className="card p-5">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <CreditCard className="w-5 h-5" />
              {t("nav.payments")} ({payments.length})
            </h3>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {payments.length === 0 ? (
                <div className="text-center py-8 text-[var(--text-muted)]">
                  {t("common.noData")}
                </div>
              ) : (
                payments.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center justify-between p-3 rounded-lg hover:bg-[var(--bg-muted)]"
                  >
                    <div className="flex items-center gap-3">
                      <Receipt className="w-4 h-4 text-[var(--primary)]" />
                      <div>
                        <div className="font-mono text-xs">{p.receiptNumber}</div>
                        <div className="text-xs text-[var(--text-muted)]">
                          {formatDate(p.paidAt, lang)} · {t(`payments.${p.method}`)}
                        </div>
                      </div>
                    </div>
                    <div className="font-semibold text-[var(--success)]">
                      +{formatMoney(p.amount, "SAR", lang)}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="card p-5">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Wallet className="w-5 h-5" />
              {t("nav.debts")} ({debts.length})
            </h3>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {debts.length === 0 ? (
                <div className="text-center py-8 text-[var(--text-muted)]">
                  {t("common.noData")}
                </div>
              ) : (
                debts.map((d) => (
                  <div
                    key={d.id}
                    className="flex items-center justify-between p-3 rounded-lg hover:bg-[var(--bg-muted)]"
                  >
                    <div>
                      <div className="text-sm">{d.description || d.type}</div>
                      <div className="text-xs text-[var(--text-muted)]">
                        {formatDate(d.createdAt, lang)}
                      </div>
                    </div>
                    <div
                      className={`font-semibold ${
                        d.type === "payment" ? "text-[var(--success)]" : "text-[var(--danger)]"
                      }`}
                    >
                      {d.type === "payment" ? "+" : "-"}
                      {formatMoney(d.amount, "SAR", lang)}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-3">
      <Icon className="w-4 h-4 text-[var(--text-muted)] mt-0.5" />
      <div className="flex-1 min-w-0">
        <div className="text-xs text-[var(--text-muted)]">{label}</div>
        <div className="font-medium truncate">{value}</div>
      </div>
    </div>
  );
}

function InfoBox({
  label,
  value,
  danger,
}: {
  label: string;
  value: string;
  danger?: boolean;
}) {
  return (
    <div className="p-3 rounded-lg bg-[var(--bg-muted)] text-center">
      <div className="text-xs text-[var(--text-muted)]">{label}</div>
      <div className={`font-bold mt-1 ${danger ? "text-[var(--danger)]" : ""}`}>
        {value}
      </div>
    </div>
  );
}
