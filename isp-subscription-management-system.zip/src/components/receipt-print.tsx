"use client";

import { useEffect } from "react";
import { useApp } from "@/components/providers";
import { formatMoney, formatDate } from "@/lib/utils";
import type { getReceipt } from "@/app/actions";

type Data = NonNullable<Awaited<ReturnType<typeof getReceipt>>>;

export function ReceiptPrint({ data }: { data: Data }) {
  const { t, lang } = useApp();
  const { payment, subscriber, tenant, template } = data;
  const accent = template?.accentColor || "#0ea5e9";

  useEffect(() => {
    const timer = setTimeout(() => window.print(), 500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div
      className="max-w-2xl mx-auto p-8 bg-white text-slate-900"
      style={{ fontFamily: "Tajawal, Inter, Arial, sans-serif" }}
    >
      <div className="border-b-4 pb-4 mb-6" style={{ borderColor: accent }}>
        <div className="text-center">
          <div
            className="inline-block w-16 h-16 rounded-full text-white font-bold text-2xl flex items-center justify-center mx-auto mb-3"
            style={{ background: accent }}
          >
            {tenant.name.charAt(0)}
          </div>
          <h1 className="text-2xl font-bold">{tenant.name}</h1>
          {tenant.phone && (
            <div className="text-sm text-slate-600">{tenant.phone}</div>
          )}
          {tenant.address && (
            <div className="text-xs text-slate-500">{tenant.address}</div>
          )}
          <h2 className="text-xl font-bold mt-4" style={{ color: accent }}>
            {t("receipts.title").replace(/.*\s/, "") === "" ? "Receipt" : lang === "ar" ? "إيصال قبض" : "Receipt"}
          </h2>
        </div>
      </div>

      <div className="flex justify-between text-sm mb-6">
        <div>
          <strong>{t("receipts.number")}:</strong> {payment.receiptNumber}
        </div>
        <div>
          <strong>{t("receipts.date")}:</strong> {formatDate(payment.paidAt, lang)}
        </div>
      </div>

      <div className="bg-slate-50 p-4 rounded-lg mb-4">
        <div className="text-xs text-slate-500">{t("receipts.receivedFrom")}</div>
        <div className="text-lg font-bold">{subscriber.fullName}</div>
        {subscriber.phone && (
          <div className="text-sm text-slate-600">{subscriber.phone}</div>
        )}
      </div>

      <div
        className="p-5 rounded-lg text-white text-center mb-4"
        style={{ background: accent }}
      >
        <div className="text-xs opacity-90">{t("receipts.amountPaid")}</div>
        <div className="text-3xl font-bold">
          {formatMoney(payment.amount, tenant.currency || "SAR", lang)}
        </div>
      </div>

      <table className="w-full text-sm mb-6">
        <tbody>
          <tr className="border-b">
            <td className="py-2 text-slate-600">{t("payments.method")}</td>
            <td className="py-2 text-end font-medium">
              {t(`payments.${payment.method}`)}
            </td>
          </tr>
          <tr className="border-b">
            <td className="py-2 text-slate-600">{t("payments.type")}</td>
            <td className="py-2 text-end font-medium">
              {t(`payments.${payment.type}`)}
            </td>
          </tr>
          <tr className="border-b">
            <td className="py-2 text-slate-600">{t("payments.monthsCovered")}</td>
            <td className="py-2 text-end font-medium">{payment.monthsCovered}</td>
          </tr>
          {payment.note && (
            <tr>
              <td className="py-2 text-slate-600">{t("common.notes")}</td>
              <td className="py-2 text-end">{payment.note}</td>
            </tr>
          )}
        </tbody>
      </table>

      <div className="text-center py-4" style={{ color: accent }}>
        <div className="font-semibold">
          {template?.thankYouMessage || t("receipts.thankYou")}
        </div>
      </div>

      {template?.footerText && (
        <div className="text-center text-xs text-slate-400 mt-4">
          {template.footerText}
        </div>
      )}
    </div>
  );
}
