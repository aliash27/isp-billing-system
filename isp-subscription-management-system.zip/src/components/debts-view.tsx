"use client";

import { useApp } from "@/components/providers";
import { Wallet, Phone, AlertCircle } from "lucide-react";
import { formatMoney } from "@/lib/utils";
import type { listDebtors } from "@/app/actions";

export function DebtsView({
  rows,
}: {
  rows: Awaited<ReturnType<typeof listDebtors>>;
}) {
  const { t, lang } = useApp();

  const totalDebt = rows.reduce(
    (sum, r) => sum + parseFloat(r.debtAmount),
    0
  );

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">{t("nav.debts")}</h1>
          <p className="text-sm text-[var(--text-muted)]">
            {rows.length} {lang === "ar" ? "مدين" : "debtors"}
          </p>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-rose-500 to-pink-600 flex items-center justify-center text-white">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-[var(--text-muted)]">
              {t("reports.totalDebt")}
            </div>
            <div className="text-xl font-bold text-[var(--danger)]">
              {formatMoney(totalDebt, "SAR", lang)}
            </div>
          </div>
        </div>
      </div>

      <div className="table-wrap">
        <div className="overflow-x-auto">
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>{t("common.name")}</th>
                <th>{t("common.phone")}</th>
                <th>{t("subscribers.area")}</th>
                <th>{t("subscribers.debtAmount")}</th>
                <th>{t("common.status")}</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-[var(--text-muted)]">
                    {t("common.noData")}
                  </td>
                </tr>
              ) : (
                rows.map((s, i) => (
                  <tr key={s.id}>
                    <td className="text-[var(--text-muted)]">{i + 1}</td>
                    <td>
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-rose-500 to-pink-600 flex items-center justify-center text-white font-semibold text-xs">
                          {s.fullName.charAt(0)}
                        </div>
                        <div className="font-medium">{s.fullName}</div>
                      </div>
                    </td>
                    <td className="font-mono text-xs">{s.phone || "—"}</td>
                    <td>{s.area || "—"}</td>
                    <td>
                      <span className="font-bold text-[var(--danger)] flex items-center gap-1">
                        <AlertCircle className="w-4 h-4" />
                        {formatMoney(s.debtAmount, "SAR", lang)}
                      </span>
                    </td>
                    <td>
                      <span className="badge badge-warning">
                        {t(`subscribers.${s.status}`)}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
