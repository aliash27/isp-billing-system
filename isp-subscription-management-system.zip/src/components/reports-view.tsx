"use client";

import { useApp } from "@/components/providers";
import {
  Calendar,
  CalendarDays,
  Users,
  TrendingUp,
  UserCheck,
  Clock,
  Download,
} from "lucide-react";
import { useState } from "react";
import { getReport } from "@/app/actions";
import { formatMoney, formatDate } from "@/lib/utils";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  LineChart,
  Line,
} from "recharts";

type ReportType =
  | "daily"
  | "monthly"
  | "debtors"
  | "expiring"
  | "accountants";

export function ReportsView() {
  const { t, lang } = useApp();
  const [type, setType] = useState<ReportType>("daily");
  const [from, setFrom] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 30);
    return d.toISOString().slice(0, 10);
  });
  const [to, setTo] = useState(() => new Date().toISOString().slice(0, 10));
  const [data, setData] = useState<unknown[]>([]);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const result = await getReport(type, { from, to });
      setData(result as unknown[]);
    } catch {
      setData([]);
    } finally {
      setLoading(false);
    }
  };

  const types = [
    { id: "daily" as const, icon: Calendar, label: t("reports.dailyCollections") },
    { id: "monthly" as const, icon: CalendarDays, label: t("reports.monthlyCollections") },
    { id: "debtors" as const, icon: Users, label: t("reports.debtors") },
    { id: "expiring" as const, icon: Clock, label: t("reports.expiringSubscriptions") },
    { id: "accountants" as const, icon: UserCheck, label: t("reports.accountantPerformance") },
  ];

  const exportCSV = () => {
    if (data.length === 0) return;
    const headers = Object.keys(data[0] as object);
    const csv = [
      headers.join(","),
      ...(data as Array<Record<string, unknown>>).map((r) =>
        headers.map((h) => `"${String(r[h] ?? "")}"`).join(",")
      ),
    ].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `report-${type}-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">{t("reports.title")}</h1>
        <p className="text-sm text-[var(--text-muted)]">
          {t("reports.period")}: {from} → {to}
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {types.map((ty) => {
          const Icon = ty.icon;
          return (
            <button
              key={ty.id}
              onClick={() => setType(ty.id)}
              className={`card p-4 text-start transition ${
                type === ty.id
                  ? "ring-2 ring-[var(--primary)] shadow-lg"
                  : "hover:shadow"
              }`}
            >
              <Icon
                className={`w-5 h-5 mb-2 ${
                  type === ty.id ? "text-[var(--primary)]" : "text-[var(--text-muted)]"
                }`}
              />
              <div className="text-sm font-medium">{ty.label}</div>
            </button>
          );
        })}
      </div>

      <div className="card p-4 flex flex-col sm:flex-row gap-3 items-end">
        <div className="flex-1 grid grid-cols-2 gap-3 w-full">
          <div>
            <label className="text-xs text-[var(--text-muted)]">
              {t("common.from")}
            </label>
            <input
              type="date"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              className="input"
            />
          </div>
          <div>
            <label className="text-xs text-[var(--text-muted)]">
              {t("common.to")}
            </label>
            <input
              type="date"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              className="input"
            />
          </div>
        </div>
        <button onClick={load} disabled={loading} className="btn btn-primary">
          {loading ? t("common.loading") : t("common.filter")}
        </button>
        <button onClick={exportCSV} className="btn btn-ghost">
          <Download className="w-4 h-4" />
          {t("common.export")} CSV
        </button>
      </div>

      <ReportResults type={type} data={data} />
    </div>
  );
}

function ReportResults({ type, data }: { type: ReportType; data: unknown[] }) {
  const { t, lang } = useApp();

  if (data.length === 0) {
    return (
      <div className="card p-12 text-center text-[var(--text-muted)]">
        {t("common.noData")}
      </div>
    );
  }

  if (type === "daily" || type === "monthly") {
    const chartData = (data as Array<{ date?: string; month?: string; total: string; count: number }>).map(
      (r) => ({
        label: r.date || r.month || "",
        total: parseFloat(r.total),
        count: r.count,
      })
    );
    const totalCollected = chartData.reduce((s, r) => s + r.total, 0);

    return (
      <div className="space-y-4">
        <div className="card p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white">
              <TrendingUp className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs text-[var(--text-muted)]">
                {t("reports.totalCollected")}
              </div>
              <div className="text-2xl font-bold">
                {formatMoney(totalCollected, "SAR", lang)}
              </div>
            </div>
          </div>
          <div className="text-end">
            <div className="text-xs text-[var(--text-muted)]">
              {t("reports.count")}
            </div>
            <div className="text-2xl font-bold">
              {chartData.reduce((s, r) => s + r.count, 0)}
            </div>
          </div>
        </div>

        <div className="card p-5">
          <div style={{ width: "100%", height: 320 }}>
            <ResponsiveContainer>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="label" stroke="var(--text-muted)" fontSize={11} />
                <YAxis stroke="var(--text-muted)" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    background: "var(--card)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    color: "var(--text)",
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="total"
                  stroke="var(--primary)"
                  strokeWidth={3}
                  dot={{ fill: "var(--primary)", r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    );
  }

  if (type === "debtors" || type === "expiring") {
    const rows = data as Array<{
      id: string;
      fullName: string;
      phone?: string | null;
      debtAmount?: string;
      nextBillingAt?: Date | string | null;
    }>;
    return (
      <div className="table-wrap">
        <div className="overflow-x-auto">
          <table>
            <thead>
              <tr>
                <th>{t("common.name")}</th>
                <th>{t("common.phone")}</th>
                {type === "debtors" ? (
                  <th>{t("subscribers.debtAmount")}</th>
                ) : (
                  <th>{t("subscribers.nextBilling")}</th>
                )}
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td className="font-medium">{r.fullName}</td>
                  <td className="font-mono text-xs">{r.phone || "—"}</td>
                  <td className="font-semibold">
                    {type === "debtors"
                      ? formatMoney(r.debtAmount, "SAR", lang)
                      : formatDate(r.nextBillingAt, lang)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  if (type === "accountants") {
    const rows = data as Array<{
      userId: string;
      fullName: string;
      totalPayments: number;
      totalAmount: string;
    }>;
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {rows.map((r) => (
          <div key={r.userId} className="card p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-gradient-primary flex items-center justify-center text-white font-semibold">
                {r.fullName.charAt(0)}
              </div>
              <div>
                <div className="font-bold">{r.fullName}</div>
                <div className="text-xs text-[var(--text-muted)]">
                  {t("roles.accountant")}
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="p-3 rounded-lg bg-[var(--bg-muted)]">
                <div className="text-xs text-[var(--text-muted)]">
                  {t("reports.count")}
                </div>
                <div className="text-xl font-bold">{r.totalPayments}</div>
              </div>
              <div className="p-3 rounded-lg bg-[var(--bg-muted)]">
                <div className="text-xs text-[var(--text-muted)]">
                  {t("reports.totalCollected")}
                </div>
                <div className="text-xl font-bold text-[var(--success)]">
                  {formatMoney(r.totalAmount, "SAR", lang)}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return null;
}
