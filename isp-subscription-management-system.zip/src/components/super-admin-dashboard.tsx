"use client";

import { useApp } from "@/components/providers";
import {
  Building2,
  Users,
  UserCheck,
  Wallet,
  ShieldAlert,
  CreditCard,
  TrendingUp,
  CheckCircle,
  XCircle,
} from "lucide-react";
import { useState } from "react";
import { formatMoney, formatDate } from "@/lib/utils";
import {
  approveUser,
  createTenant,
  type getSuperAdminOverview,
} from "@/app/super-admin/actions";
import { useRouter } from "next/navigation";

export function SuperAdminDashboard({
  data,
}: {
  data: Awaited<ReturnType<typeof getSuperAdminOverview>>;
}) {
  const { t, lang } = useApp();
  const router = useRouter();
  const [showCreate, setShowCreate] = useState(false);

  const stats = [
    {
      title: t("superAdmin.totalTenants"),
      value: data.tenantStats.total,
      icon: Building2,
      color: "from-violet-500 to-purple-600",
    },
    {
      title: t("superAdmin.activeTenants"),
      value: data.tenantStats.active,
      icon: CheckCircle,
      color: "from-emerald-500 to-teal-600",
    },
    {
      title: lang === "ar" ? "حسابات تجريبية" : "Trial Accounts",
      value: data.tenantStats.trial,
      icon: ShieldAlert,
      color: "from-amber-500 to-orange-600",
    },
    {
      title: lang === "ar" ? "إجمالي المشتركين" : "Total Subscribers",
      value: data.totalSubscribers,
      icon: Users,
      color: "from-sky-500 to-blue-600",
    },
    {
      title: t("superAdmin.globalRevenue"),
      value: formatMoney(data.globalRevenue, "SAR", lang),
      icon: Wallet,
      color: "from-pink-500 to-rose-600",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-3xl font-bold">{t("superAdmin.title")}</h1>
          <p className="text-[var(--text-muted)] mt-1">
            {lang === "ar" ? "إدارة كاملة للنظام" : "Full system management"}
          </p>
        </div>
        <button onClick={() => setShowCreate(true)} className="btn btn-primary">
          <Building2 className="w-4 h-4" />
          {t("superAdmin.createTenant")}
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.title} className="card p-5 slide-in">
              <div
                className={`w-11 h-11 rounded-xl bg-gradient-to-br ${s.color} flex items-center justify-center text-white shadow-lg mb-3`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <div className="text-2xl font-bold">{s.value}</div>
              <div className="text-xs text-[var(--text-muted)] mt-1">{s.title}</div>
            </div>
          );
        })}
      </div>

      {data.pendingUsers.length > 0 && (
        <div className="card p-5">
          <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-[var(--warning)]" />
            {t("superAdmin.pendingApprovals")} ({data.pendingUsers.length})
          </h3>
          <div className="space-y-2">
            {data.pendingUsers.map(({ user, tenant }) => (
              <div
                key={user.id}
                className="flex items-center justify-between p-3 rounded-lg bg-[var(--bg-muted)]"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-primary flex items-center justify-center text-white font-semibold">
                    {user.fullName.charAt(0)}
                  </div>
                  <div>
                    <div className="font-medium">{user.fullName}</div>
                    <div className="text-xs text-[var(--text-muted)]">
                      {user.email} · {tenant?.name || "—"} · {t(`roles.${user.role}`)}
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={async () => {
                      await approveUser(user.id);
                      router.refresh();
                    }}
                    className="btn btn-success !py-1.5 !px-3"
                  >
                    <CheckCircle className="w-4 h-4" />
                    {t("superAdmin.approveUser")}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-5">
          <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
            <Building2 className="w-5 h-5" />
            {lang === "ar" ? "أحدث الشركات" : "Recent Companies"}
          </h3>
          <div className="space-y-2">
            {data.recentTenants.map((t) => (
              <div
                key={t.id}
                className="flex items-center justify-between p-3 rounded-lg hover:bg-[var(--bg-muted)]"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-white font-semibold">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-medium">{t.name}</div>
                    <div className="text-xs text-[var(--text-muted)]">
                      {t.email} · {formatDate(t.createdAt, lang)}
                    </div>
                  </div>
                </div>
                <span
                  className={`badge ${
                    t.status === "active"
                      ? "badge-success"
                      : t.status === "trial"
                        ? "badge-info"
                        : "badge-danger"
                  }`}
                >
                  {t.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-5">
          <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
            <CreditCard className="w-5 h-5" />
            {t("superAdmin.plans")}
          </h3>
          <div className="space-y-2">
            {data.plans.map((p) => (
              <div
                key={p.id}
                className="flex items-center justify-between p-3 rounded-lg bg-[var(--bg-muted)]"
              >
                <div>
                  <div className="font-medium">{p.name}</div>
                  <div className="text-xs text-[var(--text-muted)]">
                    {p.durationDays} {lang === "ar" ? "يوم" : "days"}
                  </div>
                </div>
                <div className="text-end">
                  <div className="font-bold">{formatMoney(p.price, "SAR", lang)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {showCreate && (
        <CreateTenantForm
          plans={data.plans}
          onClose={() => setShowCreate(false)}
          onSaved={() => {
            setShowCreate(false);
            router.refresh();
          }}
        />
      )}
    </div>
  );
}

function CreateTenantForm({
  plans,
  onClose,
  onSaved,
}: {
  plans: Awaited<ReturnType<typeof getSuperAdminOverview>>["plans"];
  onClose: () => void;
  onSaved: () => void;
}) {
  const { t } = useApp();
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    const fd = new FormData(e.currentTarget);
    try {
      await createTenant({
        name: String(fd.get("name")),
        slug: String(fd.get("slug") || ""),
        email: String(fd.get("email")),
        password: String(fd.get("password")),
        phone: String(fd.get("phone") || ""),
        address: String(fd.get("address") || ""),
        planCode: String(fd.get("planCode")),
        trialDays: parseInt(String(fd.get("trialDays") || "0")),
      });
      onSaved();
    } catch (e) {
      alert((e as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 modal-overlay flex items-center justify-center p-4">
      <div className="card w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="p-5 border-b border-[var(--border)] flex items-center justify-between">
          <h2 className="text-lg font-bold">{t("superAdmin.createTenant")}</h2>
          <button onClick={onClose}>✕</button>
        </div>
        <form onSubmit={onSubmit} className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-medium mb-1.5 block">{t("common.name")} *</label>
              <input name="name" className="input" required />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Slug</label>
              <input name="slug" className="input" />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">{t("auth.email")} *</label>
              <input name="email" type="email" className="input" required />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">{t("auth.password")} *</label>
              <input name="password" type="text" className="input" required defaultValue="admin123" />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">{t("common.phone")}</label>
              <input name="phone" className="input" />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">{t("superAdmin.trialDays")}</label>
              <input name="trialDays" type="number" className="input" defaultValue="14" />
            </div>
            <div className="col-span-2">
              <label className="text-sm font-medium mb-1.5 block">{t("common.address")}</label>
              <input name="address" className="input" />
            </div>
            <div className="col-span-2">
              <label className="text-sm font-medium mb-1.5 block">{t("superAdmin.plans")} *</label>
              <select name="planCode" className="input" required>
                {plans.map((p) => (
                  <option key={p.id} value={p.code}>
                    {p.name} — {p.price} / {p.durationDays}d
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-4 border-t border-[var(--border)]">
            <button type="button" onClick={onClose} className="btn btn-ghost">
              {t("common.cancel")}
            </button>
            <button type="submit" disabled={loading} className="btn btn-primary">
              {loading ? t("common.loading") : t("common.create")}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
