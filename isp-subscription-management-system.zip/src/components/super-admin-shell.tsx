"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useApp } from "@/components/providers";
import {
  LayoutDashboard,
  Building2,
  CreditCard,
  Users,
  UserCheck,
  ShieldAlert,
  ScrollText,
  LogOut,
  Moon,
  Sun,
  Globe,
  Menu,
  X,
  Wifi,
  Lock,
} from "lucide-react";
import { useState } from "react";
import type { SessionUser } from "@/lib/auth";
import { cn } from "@/lib/utils";
import { lockExpiredTenants } from "@/app/super-admin/actions";

export function SuperAdminShell({
  session,
  children,
}: {
  session: SessionUser;
  children: React.ReactNode;
}) {
  const { t, lang, setLang, theme, setTheme, dir } = useApp();
  const pathname = usePathname();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);

  const nav = [
    { href: "/super-admin", icon: LayoutDashboard, label: t("nav.dashboard") },
    { href: "/super-admin/tenants", icon: Building2, label: t("superAdmin.tenants") },
    { href: "/super-admin/plans", icon: CreditCard, label: t("superAdmin.plans") },
    { href: "/super-admin/users", icon: Users, label: t("nav.users") },
    { href: "/super-admin/audit", icon: ScrollText, label: t("nav.audit") },
  ];

  const onLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  };

  const lockExpired = async () => {
    if (!confirm(lang === "ar" ? "تأكيد قفل الحسابات المنتهية؟" : "Confirm lock expired?")) return;
    const res = await lockExpiredTenants();
    alert(`${lang === "ar" ? "تم قفل" : "Locked"}: ${res.count}`);
    router.refresh();
  };

  return (
    <div className="min-h-screen flex bg-[var(--bg)]">
      <aside
        className={cn(
          "fixed lg:sticky top-0 z-40 h-screen w-72 bg-[var(--sidebar-bg)] border-e border-[var(--border)] flex flex-col transition-transform",
          mobileOpen ? "translate-x-0" : dir === "rtl" ? "translate-x-full lg:translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        <div className="p-5 border-b border-[var(--border)]">
          <Link href="/super-admin" className="flex items-center gap-3">
            <div className="w-11 h-11 bg-gradient-to-br from-violet-500 to-purple-700 rounded-xl flex items-center justify-center text-white shadow-lg">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-bold text-sm">{t("superAdmin.title")}</div>
              <div className="text-xs text-[var(--text-muted)]">
                {session.fullName}
              </div>
            </div>
            <button
              onClick={() => setMobileOpen(false)}
              className="lg:hidden p-1 rounded hover:bg-[var(--bg-muted)]"
            >
              <X className="w-4 h-4" />
            </button>
          </Link>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {nav.map((item) => {
            const Icon = item.icon;
            const active =
              item.href === "/super-admin"
                ? pathname === "/super-admin"
                : pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all",
                  active
                    ? "bg-gradient-to-r from-violet-500 to-purple-600 text-white shadow-md"
                    : "text-[var(--sidebar-text)] hover:bg-[var(--bg-muted)]"
                )}
              >
                <Icon className="w-5 h-5 shrink-0" />
                <span>{item.label}</span>
              </Link>
            );
          })}
          <button
            onClick={lockExpired}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-[var(--warning)] hover:bg-[color-mix(in_srgb,var(--warning)_10%,transparent)]"
          >
            <Lock className="w-5 h-5" />
            {t("superAdmin.lockExpired")}
          </button>
        </nav>

        <div className="p-3 border-t border-[var(--border)]">
          <button onClick={onLogout} className="btn btn-ghost w-full !justify-start">
            <LogOut className="w-4 h-4" />
            {t("nav.logout")}
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-30 bg-[var(--bg)]/80 backdrop-blur-xl border-b border-[var(--border)]">
          <div className="flex items-center justify-between px-4 lg:px-8 h-16">
            <button
              onClick={() => setMobileOpen(true)}
              className="lg:hidden p-2 rounded-lg hover:bg-[var(--bg-muted)]"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 ms-auto">
              <span className="badge badge-danger">
                <ShieldAlert className="w-3 h-3" />
                SUPER ADMIN
              </span>
              <button
                onClick={() => setLang(lang === "ar" ? "en" : "ar")}
                className="btn btn-ghost !py-2 !px-3 text-xs"
              >
                <Globe className="w-4 h-4" />
                {lang === "ar" ? "EN" : "عربي"}
              </button>
              <button
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                className="btn btn-ghost !py-2 !px-3"
              >
                {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </header>
        <main className="flex-1 p-4 lg:p-8 fade-in">{children}</main>
      </div>

      {mobileOpen && (
        <div
          onClick={() => setMobileOpen(false)}
          className="lg:hidden fixed inset-0 z-30 bg-black/50 backdrop-blur-sm"
        />
      )}
    </div>
  );
}
