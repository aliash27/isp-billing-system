"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useApp } from "@/components/providers";
import {
  LayoutDashboard,
  Users,
  CreditCard,
  Receipt,
  FileText,
  BarChart3,
  Settings,
  LogOut,
  Moon,
  Sun,
  Globe,
  Menu,
  X,
  Wifi,
  Wallet,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { useState } from "react";
import type { SessionUser } from "@/lib/auth";
import { cn } from "@/lib/utils";

export function DashboardShell({
  session,
  children,
}: {
  session: SessionUser;
  children: React.ReactNode;
}) {
  const { t, lang, setLang, theme, setTheme, dir } = useApp();
  const pathname = usePathname();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);

  const nav = [
    { href: "/dashboard", icon: LayoutDashboard, label: t("nav.dashboard") },
    { href: "/dashboard/subscribers", icon: Users, label: t("nav.subscribers") },
    { href: "/dashboard/payments", icon: CreditCard, label: t("nav.payments") },
    { href: "/dashboard/receipts", icon: Receipt, label: t("nav.receipts") },
    { href: "/dashboard/debts", icon: Wallet, label: t("nav.debts") },
    { href: "/dashboard/invoices", icon: FileText, label: t("nav.invoices") },
    { href: "/dashboard/reports", icon: BarChart3, label: t("nav.reports") },
    ...(session.role === "admin"
      ? [{ href: "/dashboard/settings", icon: Settings, label: t("nav.settings") }]
      : []),
  ];

  const onLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  };

  const isReadonly = session.readMode;

  return (
    <div className="min-h-screen flex bg-[var(--bg)]">
      {/* Sidebar */}
      <aside
        className={cn(
          "fixed lg:sticky top-0 z-40 h-screen w-72 bg-[var(--sidebar-bg)] border-e border-[var(--border)] flex flex-col transition-transform",
          mobileOpen ? "translate-x-0" : dir === "rtl" ? "translate-x-full lg:translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        <div className="p-5 border-b border-[var(--border)]">
          <Link href="/dashboard" className="flex items-center gap-3">
            <div className="w-11 h-11 bg-gradient-primary rounded-xl flex items-center justify-center text-white shadow-lg shadow-[color-mix(in_srgb,var(--primary)_30%,transparent)]">
              <Wifi className="w-6 h-6" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-bold text-sm truncate">ISP Billing</div>
              <div className="text-xs text-[var(--text-muted)] truncate">
                {session.tenantName || session.fullName}
              </div>
            </div>
            <button
              onClick={() => setMobileOpen(false)}
              className="lg:hidden p-1 rounded hover:bg-[var(--bg-muted)]"
            >
              <X className="w-4 h-4" />
            </button>
          </Link>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {nav.map((item) => {
            const Icon = item.icon;
            const active =
              item.href === "/dashboard"
                ? pathname === "/dashboard"
                : pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all",
                  active
                    ? "bg-gradient-primary text-white shadow-md"
                    : "text-[var(--sidebar-text)] hover:bg-[var(--bg-muted)]"
                )}
              >
                <Icon className="w-5 h-5 shrink-0" />
                <span className="flex-1">{item.label}</span>
                {active && dir === "rtl" ? (
                  <ChevronLeft className="w-4 h-4" />
                ) : active ? (
                  <ChevronRight className="w-4 h-4" />
                ) : null}
              </Link>
            );
          })}
        </nav>

        {isReadonly && (
          <div className="mx-3 mb-3 p-3 rounded-lg bg-[color-mix(in_srgb,var(--warning)_15%,transparent)] border border-[color-mix(in_srgb,var(--warning)_40%,transparent)] text-[var(--warning)] text-xs flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <div>{t("messages.readonly")}</div>
          </div>
        )}

        <div className="p-3 border-t border-[var(--border)]">
          <div className="flex items-center gap-3 p-2 rounded-xl bg-[var(--bg-muted)] mb-2">
            <div className="w-9 h-9 rounded-full bg-gradient-primary flex items-center justify-center text-white font-semibold text-sm">
              {session.fullName.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">
                {session.fullName}
              </div>
              <div className="text-xs text-[var(--text-muted)] truncate">
                {t(`roles.${session.role}`)}
              </div>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="btn btn-ghost w-full !justify-start"
          >
            <LogOut className="w-4 h-4" />
            {t("nav.logout")}
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Topbar */}
        <header className="sticky top-0 z-30 bg-[var(--bg)]/80 backdrop-blur-xl border-b border-[var(--border)]">
          <div className="flex items-center justify-between px-4 lg:px-8 h-16">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setMobileOpen(true)}
                className="lg:hidden p-2 rounded-lg hover:bg-[var(--bg-muted)]"
              >
                <Menu className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setLang(lang === "ar" ? "en" : "ar")}
                className="btn btn-ghost !py-2 !px-3 text-xs"
              >
                <Globe className="w-4 h-4" />
                {lang === "ar" ? "EN" : "عربي"}
              </button>
              <button
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                className="btn btn-ghost !py-2 !px-3"
              >
                {theme === "dark" ? (
                  <Sun className="w-4 h-4" />
                ) : (
                  <Moon className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 lg:p-8 fade-in">{children}</main>
      </div>

      {/* Overlay */}
      {mobileOpen && (
        <div
          onClick={() => setMobileOpen(false)}
          className="lg:hidden fixed inset-0 z-30 bg-black/50 backdrop-blur-sm"
        />
      )}
    </div>
  );
}
