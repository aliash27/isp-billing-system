"use client";

import { useApp } from "@/components/providers";
import { Receipt, Printer, Download } from "lucide-react";
import { formatMoney, formatDate } from "@/lib/utils";
import type { listReceipts } from "@/app/actions";
import { generateReceiptPDF } from "@/lib/pdf";

type ReceiptRow = Awaited<ReturnType<typeof listReceipts>>["rows"][number];

export function ReceiptsView({
  initial,
}: {
  initial: Awaited<ReturnType<typeof listReceipts>>;
}) {
  const { t, lang } = useApp();

  const downloadPDF = async (receiptNumber: string) => {
    const res = await fetch(`/api/receipts/${encodeURIComponent(receiptNumber)}`);
    const data = await res.json();
    if (!data.ok) return;
    const { payment, subscriber, tenant, template } = data.data;
    const blob = await generateReceiptPDF({
      receiptNumber: payment.receiptNumber,
      date: formatDate(payment.paidAt, lang),
      company: {
        name: tenant.name,
        phone: tenant.phone,
        address: tenant.address,
      },
      customer: {
        fullName: subscriber.fullName,
        phone: subscriber.phone,
        address: subscriber.address,
      },
      amount: parseFloat(payment.amount),
      currency: tenant.currency || "SAR",
      method: t(`payments.${payment.method}`),
      type: t(`payments.${payment.type}`),
      monthsCovered: parseFloat(payment.monthsCovered),
      note: payment.note,
      lang,
      accentColor: template?.accentColor,
      footerText: template?.footerText,
      thankYouMessage: template?.thankYouMessage,
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${payment.receiptNumber}.pdf`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">{t("receipts.title")}</h1>
        <p className="text-sm text-[var(--text-muted)]">
          {initial.total} {lang === "ar" ? "إيصال" : "receipts"}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {initial.rows.length === 0 ? (
          <div className="col-span-full card p-12 text-center text-[var(--text-muted)]">
            {t("common.noData")}
          </div>
        ) : (
          initial.rows.map(({ payment, subscriber }) => (
            <ReceiptCard
              key={payment.id}
              row={{ payment, subscriber }}
              onPrint={() =>
                window.open(
                  `/dashboard/receipts/${encodeURIComponent(payment.receiptNumber)}/print`,
                  "_blank"
                )
              }
              onDownload={() => downloadPDF(payment.receiptNumber)}
            />
          ))
        )}
      </div>
    </div>
  );
}

function ReceiptCard({
  row,
  onPrint,
  onDownload,
}: {
  row: ReceiptRow;
  onPrint: () => void;
  onDownload: () => void;
}) {
  const { t, lang } = useApp();
  const { payment, subscriber } = row;
  return (
    <div className="card p-5 hover:shadow-lg transition">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-primary flex items-center justify-center text-white">
            <Receipt className="w-5 h-5" />
          </div>
          <div>
            <div className="font-mono text-sm font-semibold">
              {payment.receiptNumber}
            </div>
            <div className="text-xs text-[var(--text-muted)]">
              {formatDate(payment.paidAt, lang)}
            </div>
          </div>
        </div>
        <span className="badge badge-success">
          {formatMoney(payment.amount, "SAR", lang)}
        </span>
      </div>

      <div className="space-y-2 text-sm pb-4 border-b border-[var(--border)]">
        <div className="flex justify-between">
          <span className="text-[var(--text-muted)]">{t("receipts.customer")}</span>
          <span className="font-medium">{subscriber.fullName}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-[var(--text-muted)]">{t("payments.method")}</span>
          <span className="badge badge-info">{t(`payments.${payment.method}`)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-[var(--text-muted)]">{t("payments.type")}</span>
          <span className="badge badge-muted">{t(`payments.${payment.type}`)}</span>
        </div>
      </div>

      <div className="flex items-center gap-2 pt-4">
        <button onClick={onPrint} className="btn btn-ghost flex-1">
          <Printer className="w-4 h-4" />
          {t("common.print")}
        </button>
        <button onClick={onDownload} className="btn btn-primary flex-1">
          <Download className="w-4 h-4" />
          {t("common.pdf")}
        </button>
      </div>
    </div>
  );
}
