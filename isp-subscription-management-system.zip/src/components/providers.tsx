"use client";
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Lang } from "@/lib/i18n";
import { translations } from "@/lib/i18n";

type Theme = "light" | "dark" | "system";

type AppCtx = {
  lang: Lang;
  setLang: (l: Lang) => void;
  theme: Theme;
  setTheme: (t: Theme) => void;
  t: (key: string) => string;
  dir: "rtl" | "ltr";
};

const defaultCtx: AppCtx = {
  lang: "ar",
  setLang: () => {},
  theme: "light",
  setTheme: () => {},
  t: (k: string) => k,
  dir: "rtl",
};
const Ctx = createContext<AppCtx>(defaultCtx);

export function ClientProviders({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("ar");
  const [theme, setThemeState] = useState<Theme>("light");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const savedLang = (localStorage.getItem("isp_lang") as Lang) || "ar";
    const savedTheme = (localStorage.getItem("isp_theme") as Theme) || "light";
    setLangState(savedLang);
    setThemeState(savedTheme);
  }, []);

  useEffect(() => {
    if (!mounted) return;
    const root = document.documentElement;
    root.setAttribute("lang", lang);
    root.setAttribute("dir", lang === "ar" ? "rtl" : "ltr");
    localStorage.setItem("isp_lang", lang);
  }, [lang, mounted]);

  useEffect(() => {
    if (!mounted) return;
    const root = document.documentElement;
    localStorage.setItem("isp_theme", theme);
    const apply = (t: Theme) => {
      const isDark =
        t === "dark" ||
        (t === "system" &&
          window.matchMedia("(prefers-color-scheme: dark)").matches);
      if (isDark) root.classList.add("dark");
      else root.classList.remove("dark");
    };
    apply(theme);
    if (theme === "system") {
      const mq = window.matchMedia("(prefers-color-scheme: dark)");
      const handler = () => apply(theme);
      mq.addEventListener("change", handler);
      return () => mq.removeEventListener("change", handler);
    }
  }, [theme, mounted]);

  const setLang = (l: Lang) => setLangState(l);
  const setTheme = (t: Theme) => setThemeState(t);
  const dir = lang === "ar" ? "rtl" : "ltr";

  const t = (key: string): string => {
    const dict = translations[lang] as Record<string, unknown>;
    const parts = key.split(".");
    let cur: unknown = dict;
    for (const p of parts) {
      if (cur && typeof cur === "object" && p in (cur as object)) {
        cur = (cur as Record<string, unknown>)[p];
      } else {
        return key;
      }
    }
    return typeof cur === "string" ? cur : key;
  };

  return (
    <Ctx.Provider value={{ lang, setLang, theme, setTheme, t, dir }}>
      {mounted ? (
        children
      ) : (
        <div style={{ minHeight: "100vh" }}>{children}</div>
      )}
    </Ctx.Provider>
  );
}

export function useApp() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useApp must be used within ClientProviders");
  return ctx;
}
