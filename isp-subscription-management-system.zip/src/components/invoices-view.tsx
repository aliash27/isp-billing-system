"use client";

import { useApp } from "@/components/providers";
import { FileText } from "lucide-react";
import { formatMoney, formatDate } from "@/lib/utils";
import type { listInvoices } from "@/app/actions";

export function InvoicesView({
  rows,
}: {
  rows: Awaited<ReturnType<typeof listInvoices>>;
}) {
  const { t, lang } = useApp();

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">{t("nav.invoices")}</h1>
        <p className="text-sm text-[var(--text-muted)]">
          {rows.length} {lang === "ar" ? "فاتورة" : "invoices"}
        </p>
      </div>

      <div className="table-wrap">
        <div className="overflow-x-auto">
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>{t("common.name")}</th>
                <th>{t("common.amount")}</th>
                <th>{t("common.status")}</th>
                <th>{t("common.date")}</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={5} className="text-center py-12 text-[var(--text-muted)]">
                    <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    {t("common.noData")}
                  </td>
                </tr>
              ) : (
                rows.map(({ invoice, subscriber }) => (
                  <tr key={invoice.id}>
                    <td className="font-mono text-xs">{invoice.invoiceNumber}</td>
                    <td className="font-medium">{subscriber.fullName}</td>
                    <td className="font-semibold">
                      {formatMoney(invoice.amount, "SAR", lang)}
                    </td>
                    <td>
                      <span
                        className={`badge ${
                          invoice.status === "paid"
                            ? "badge-success"
                            : invoice.status === "overdue"
                              ? "badge-danger"
                              : "badge-info"
                        }`}
                      >
                        {invoice.status}
                      </span>
                    </td>
                    <td className="text-xs">{formatDate(invoice.issuedAt, lang)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
