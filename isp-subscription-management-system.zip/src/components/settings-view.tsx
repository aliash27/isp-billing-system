"use client";

import { useApp } from "@/components/providers";
import {
  Building2,
  Palette,
  Receipt,
  Shield,
  Globe,
  CreditCard,
} from "lucide-react";
import { useState } from "react";
import {
  updateTenantSettings,
  updateReceiptTemplate,
  type getTenantSettings,
} from "@/app/actions";

type Data = Awaited<ReturnType<typeof getTenantSettings>>;

export function SettingsView({ initial }: { initial: Data }) {
  const { t, lang, setLang, theme, setTheme } = useApp();
  const [tab, setTab] = useState<"company" | "receipt" | "appearance" | "subscription">(
    "company"
  );
  const [tenant, setTenant] = useState(initial.tenant);
  const [template, setTemplate] = useState(initial.template);
  const [msg, setMsg] = useState("");

  const saveCompany = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    await updateTenantSettings({
      name: String(fd.get("name")),
      phone: String(fd.get("phone") || ""),
      email: String(fd.get("email") || ""),
      address: String(fd.get("address") || ""),
      currency: String(fd.get("currency")),
      locale: String(fd.get("locale")),
    });
    setMsg(t("messages.saved"));
    setTimeout(() => setMsg(""), 2500);
  };

  const saveReceipt = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    await updateReceiptTemplate({
      headerTitle: String(fd.get("headerTitle") || ""),
      footerText: String(fd.get("footerText") || ""),
      accentColor: String(fd.get("accentColor")),
      thankYouMessage: String(fd.get("thankYouMessage") || ""),
    });
    setMsg(t("messages.saved"));
    setTimeout(() => setMsg(""), 2500);
  };

  const tabs = [
    { id: "company" as const, icon: Building2, label: t("settings.company") },
    { id: "receipt" as const, icon: Receipt, label: t("settings.receiptTemplate") },
    { id: "appearance" as const, icon: Palette, label: t("settings.theme") },
    { id: "subscription" as const, icon: CreditCard, label: t("settings.subscription") },
  ];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">{t("settings.title")}</h1>
      </div>

      {msg && (
        <div className="bg-[color-mix(in_srgb,var(--success)_15%,transparent)] text-[var(--success)] border border-[color-mix(in_srgb,var(--success)_40%,transparent)] rounded-lg p-3 text-sm">
          {msg}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-5">
        <div className="card p-2 lg:col-span-1">
          <nav className="space-y-1">
            {tabs.map((tb) => {
              const Icon = tb.icon;
              return (
                <button
                  key={tb.id}
                  onClick={() => setTab(tb.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                    tab === tb.id
                      ? "bg-gradient-primary text-white"
                      : "hover:bg-[var(--bg-muted)]"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tb.label}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="lg:col-span-3">
          {tab === "company" && tenant && (
            <form onSubmit={saveCompany} className="card p-6 space-y-4">
              <h3 className="font-semibold text-lg flex items-center gap-2">
                <Building2 className="w-5 h-5" />
                {t("settings.company")}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label={t("common.name")}>
                  <input name="name" defaultValue={tenant.name} className="input" required />
                </Field>
                <Field label={t("common.phone")}>
                  <input name="phone" defaultValue={tenant.phone || ""} className="input" />
                </Field>
                <Field label={t("auth.email")}>
                  <input name="email" defaultValue={tenant.email || ""} className="input" />
                </Field>
                <Field label={t("common.address")}>
                  <input name="address" defaultValue={tenant.address || ""} className="input" />
                </Field>
                <Field label={lang === "ar" ? "العملة" : "Currency"}>
                  <select name="currency" defaultValue={tenant.currency || "SAR"} className="input">
                    <option value="SAR">SAR - ريال سعودي</option>
                    <option value="USD">USD - Dollar</option>
                    <option value="EUR">EUR - Euro</option>
                    <option value="AED">AED - درهم إماراتي</option>
                    <option value="EGP">EGP - جنيه مصري</option>
                  </select>
                </Field>
                <Field label={t("settings.language")}>
                  <select name="locale" defaultValue={tenant.locale || "ar"} className="input">
                    <option value="ar">العربية</option>
                    <option value="en">English</option>
                  </select>
                </Field>
              </div>
              <div className="flex justify-end pt-4 border-t border-[var(--border)]">
                <button type="submit" className="btn btn-primary">
                  {t("common.save")}
                </button>
              </div>
            </form>
          )}

          {tab === "receipt" && (
            <form onSubmit={saveReceipt} className="card p-6 space-y-4">
              <h3 className="font-semibold text-lg flex items-center gap-2">
                <Receipt className="w-5 h-5" />
                {t("settings.receiptTemplate")}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label={lang === "ar" ? "عنوان الترويسة" : "Header Title"}>
                  <input
                    name="headerTitle"
                    defaultValue={template?.headerTitle || ""}
                    className="input"
                  />
                </Field>
                <Field label={lang === "ar" ? "اللون الرئيسي" : "Accent Color"}>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      name="accentColor"
                      defaultValue={template?.accentColor || "#0ea5e9"}
                      className="w-12 h-10 rounded border border-[var(--border)] cursor-pointer"
                    />
                    <input
                      name="accentColorText"
                      defaultValue={template?.accentColor || "#0ea5e9"}
                      className="input"
                      readOnly
                    />
                  </div>
                </Field>
                <Field label={lang === "ar" ? "رسالة الشكر" : "Thank You Message"} className="md:col-span-2">
                  <input
                    name="thankYouMessage"
                    defaultValue={template?.thankYouMessage || ""}
                    className="input"
                  />
                </Field>
                <Field label={lang === "ar" ? "نص الفوتر" : "Footer Text"} className="md:col-span-2">
                  <input
                    name="footerText"
                    defaultValue={template?.footerText || ""}
                    className="input"
                  />
                </Field>
              </div>
              <div className="flex justify-end pt-4 border-t border-[var(--border)]">
                <button type="submit" className="btn btn-primary">
                  {t("common.save")}
                </button>
              </div>
            </form>
          )}

          {tab === "appearance" && (
            <div className="card p-6 space-y-6">
              <h3 className="font-semibold text-lg flex items-center gap-2">
                <Palette className="w-5 h-5" />
                {t("settings.theme")}
              </h3>
              <div>
                <div className="text-sm font-medium mb-3">{t("settings.theme")}</div>
                <div className="grid grid-cols-3 gap-3">
                  {(["light", "dark", "system"] as const).map((th) => (
                    <button
                      key={th}
                      onClick={() => setTheme(th)}
                      className={`p-4 rounded-xl border-2 transition ${
                        theme === th
                          ? "border-[var(--primary)] bg-[color-mix(in_srgb,var(--primary)_10%,transparent)]"
                          : "border-[var(--border)] hover:border-[var(--primary)]"
                      }`}
                    >
                      <div className="text-sm font-medium capitalize">
                        {t(`settings.${th}` as "settings.dark")}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="text-sm font-medium mb-3 flex items-center gap-2">
                  <Globe className="w-4 h-4" />
                  {t("settings.language")}
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {(["ar", "en"] as const).map((l) => (
                    <button
                      key={l}
                      onClick={() => setLang(l)}
                      className={`p-4 rounded-xl border-2 transition ${
                        lang === l
                          ? "border-[var(--primary)] bg-[color-mix(in_srgb,var(--primary)_10%,transparent)]"
                          : "border-[var(--border)] hover:border-[var(--primary)]"
                      }`}
                    >
                      <div className="text-sm font-medium">
                        {l === "ar" ? "العربية" : "English"}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {tab === "subscription" && tenant && (
            <div className="card p-6 space-y-4">
              <h3 className="font-semibold text-lg flex items-center gap-2">
                <CreditCard className="w-5 h-5" />
                {t("settings.subscription")}
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                <InfoCard label={lang === "ar" ? "الحالة" : "Status"}>
                  <span
                    className={`badge ${
                      tenant.status === "active"
                        ? "badge-success"
                        : tenant.status === "trial"
                          ? "badge-info"
                          : "badge-danger"
                    }`}
                  >
                    {t(`statuses.${tenant.status}` as "statuses.active")}
                  </span>
                </InfoCard>
                <InfoCard label={lang === "ar" ? "تاريخ الانتهاء" : "Expires"}>
                  <div className="text-sm font-semibold">
                    {tenant.subscriptionEndsAt
                      ? new Date(tenant.subscriptionEndsAt).toLocaleDateString()
                      : "—"}
                  </div>
                </InfoCard>
                <InfoCard label={lang === "ar" ? "العملة" : "Currency"}>
                  <div className="text-sm font-semibold">{tenant.currency}</div>
                </InfoCard>
              </div>
              <div className="p-4 rounded-lg bg-[color-mix(in_srgb,var(--primary)_10%,transparent)] border border-[color-mix(in_srgb,var(--primary)_30%,transparent)] flex items-start gap-3">
                <Shield className="w-5 h-5 text-[var(--primary)] shrink-0 mt-0.5" />
                <div className="text-sm">
                  {lang === "ar"
                    ? "لترقية خطتك أو تجديدها، يرجى التواصل مع الإدارة العليا."
                    : "To upgrade or renew your plan, please contact Super Admin."}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <label className="block text-sm font-medium mb-1.5">{label}</label>
      {children}
    </div>
  );
}

function InfoCard({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="p-3 rounded-lg bg-[var(--bg-muted)]">
      <div className="text-xs text-[var(--text-muted)] mb-1">{label}</div>
      {children}
    </div>
  );
}
