"use client";

import { useApp } from "@/components/providers";
import {
  Search,
  Plus,
  Phone,
  MapPin,
  MoreVertical,
  X,
  Eye,
  Edit2,
  Trash2,
  DollarSign,
} from "lucide-react";
import { useState, useTransition, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  createSubscriber,
  updateSubscriber,
  deleteSubscriber,
  type listSubscribers,
} from "@/app/actions";
import { cn, formatMoney, formatDate } from "@/lib/utils";

type SubscriberRow = Awaited<ReturnType<typeof listSubscribers>>["rows"][number];

export function SubscribersView({
  initial,
  searchParams,
}: {
  initial: Awaited<ReturnType<typeof listSubscribers>>;
  searchParams: { q?: string; status?: string; page?: string };
}) {
  const { t, lang } = useApp();
  const router = useRouter();
  const sp = useSearchParams();

  const [rows, setRows] = useState(initial.rows);
  const [total, setTotal] = useState(initial.total);
  const [page, setPage] = useState(initial.page);
  const [pages, setPages] = useState(initial.pages);
  const [isPending, startTransition] = useTransition();

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<SubscriberRow | null>(null);

  const refresh = (p = page, q = searchParams.q, s = searchParams.status) => {
    startTransition(async () => {
      const { listSubscribers: fn } = await import("@/app/actions");
      const r = await fn({ q, status: s, page: p });
      setRows(r.rows);
      setTotal(r.total);
      setPage(r.page);
      setPages(r.pages);
    });
  };

  useEffect(() => {
    setRows(initial.rows);
    setTotal(initial.total);
    setPage(initial.page);
    setPages(initial.pages);
  }, [initial]);

  const onSearch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const q = String(fd.get("q") || "");
    const status = String(fd.get("status") || "all");
    const params = new URLSearchParams(sp.toString());
    if (q) params.set("q", q);
    else params.delete("q");
    if (status && status !== "all") params.set("status", status);
    else params.delete("status");
    params.delete("page");
    router.push(`/dashboard/subscribers?${params.toString()}`);
  };

  const onDelete = async (id: string) => {
    if (!confirm(t("messages.confirmDelete"))) return;
    await deleteSubscriber(id);
    refresh();
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">{t("subscribers.title")}</h1>
          <p className="text-sm text-[var(--text-muted)]">
            {total} {lang === "ar" ? "مشترك" : "subscribers"}
          </p>
        </div>
        <button
          onClick={() => {
            setEditing(null);
            setShowForm(true);
          }}
          className="btn btn-primary"
        >
          <Plus className="w-4 h-4" />
          {t("subscribers.addNew")}
        </button>
      </div>

      <form
        onSubmit={onSearch}
        className="card p-4 flex flex-col sm:flex-row gap-3"
      >
        <div className="relative flex-1">
          <Search className="absolute top-1/2 -translate-y-1/2 start-3 w-4 h-4 text-[var(--text-muted)]" />
          <input
            name="q"
            defaultValue={searchParams.q}
            className="input ps-10"
            placeholder={t("common.search") + "..."}
          />
        </div>
        <select
          name="status"
          defaultValue={searchParams.status || "all"}
          className="input sm:w-48"
        >
          <option value="all">{t("common.all")}</option>
          <option value="active">{t("subscribers.active")}</option>
          <option value="expired">{t("subscribers.expired")}</option>
          <option value="suspended">{t("subscribers.suspended")}</option>
          <option value="cancelled">{t("subscribers.cancelled")}</option>
        </select>
        <button type="submit" className="btn btn-ghost">
          {t("common.filter")}
        </button>
      </form>

      <div className="table-wrap">
        <div className="overflow-x-auto">
          <table>
            <thead>
              <tr>
                <th>{t("subscribers.fullName")}</th>
                <th>{t("subscribers.phone")}</th>
                <th>{t("subscribers.area")}</th>
                <th>{t("subscribers.subscriptionType")}</th>
                <th>{t("subscribers.monthlyFee")}</th>
                <th>{t("subscribers.debtAmount")}</th>
                <th>{t("common.status")}</th>
                <th>{t("common.actions")}</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-12 text-[var(--text-muted)]">
                    {t("common.noData")}
                  </td>
                </tr>
              ) : (
                rows.map((s) => (
                  <tr key={s.id}>
                    <td>
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-gradient-primary flex items-center justify-center text-white font-semibold text-xs">
                          {s.fullName.charAt(0)}
                        </div>
                        <div>
                          <div className="font-medium">{s.fullName}</div>
                          <div className="text-xs text-[var(--text-muted)]">
                            {formatDate(s.createdAt, lang)}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="font-mono text-xs">{s.phone || "—"}</td>
                    <td>{s.area || "—"}</td>
                    <td>
                      <span className="badge badge-info">
                        {t(`subscribers.${s.subscriptionType}`)}
                      </span>
                    </td>
                    <td className="font-semibold">
                      {formatMoney(s.monthlyFee, "SAR", lang)}
                    </td>
                    <td>
                      <span
                        className={cn(
                          "font-semibold",
                          parseFloat(s.debtAmount) > 0
                            ? "text-[var(--danger)]"
                            : "text-[var(--success)]"
                        )}
                      >
                        {formatMoney(s.debtAmount, "SAR", lang)}
                      </span>
                    </td>
                    <td>
                      <span
                        className={cn(
                          "badge",
                          s.status === "active" && "badge-success",
                          s.status === "expired" && "badge-danger",
                          s.status === "suspended" && "badge-warning",
                          s.status === "cancelled" && "badge-muted"
                        )}
                      >
                        {t(`subscribers.${s.status}`)}
                      </span>
                    </td>
                    <td>
                      <div className="flex items-center gap-1">
                        <a
                          href={`/dashboard/subscribers/${s.id}`}
                          className="p-2 rounded-lg hover:bg-[var(--bg-muted)]"
                          title={t("common.view")}
                        >
                          <Eye className="w-4 h-4" />
                        </a>
                        <button
                          onClick={() => {
                            setEditing(s);
                            setShowForm(true);
                          }}
                          className="p-2 rounded-lg hover:bg-[var(--bg-muted)]"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onDelete(s.id)}
                          className="p-2 rounded-lg hover:bg-[color-mix(in_srgb,var(--danger)_15%,transparent)] text-[var(--danger)]"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {pages > 1 && (
        <div className="flex items-center justify-center gap-2">
          {Array.from({ length: pages }, (_, i) => i + 1).map((p) => (
            <button
              key={p}
              onClick={() => {
                const params = new URLSearchParams(sp.toString());
                params.set("page", String(p));
                router.push(`/dashboard/subscribers?${params.toString()}`);
              }}
              className={cn(
                "btn !p-2 min-w-[40px]",
                p === page ? "btn-primary" : "btn-ghost"
              )}
            >
              {p}
            </button>
          ))}
        </div>
      )}

      {showForm && (
        <SubscriberForm
          editing={editing}
          onClose={() => {
            setShowForm(false);
            setEditing(null);
          }}
          onSaved={() => {
            setShowForm(false);
            setEditing(null);
            refresh();
          }}
        />
      )}
    </div>
  );
}

function SubscriberForm({
  editing,
  onClose,
  onSaved,
}: {
  editing: SubscriberRow | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { t } = useApp();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    const fd = new FormData(e.currentTarget);
    const data = {
      fullName: String(fd.get("fullName")),
      phone: String(fd.get("phone") || ""),
      secondaryPhone: String(fd.get("secondaryPhone") || ""),
      address: String(fd.get("address") || ""),
      area: String(fd.get("area") || ""),
      subscriptionType: fd.get("subscriptionType") as
        | "monthly"
        | "quarterly"
        | "semi_annual"
        | "annual",
      monthlyFee: String(fd.get("monthlyFee")),
      dueDate: String(fd.get("dueDate") || "1"),
      notes: String(fd.get("notes") || ""),
    };
    try {
      if (editing) {
        await updateSubscriber(editing.id, data);
      } else {
        await createSubscriber(data);
      }
      onSaved();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 modal-overlay flex items-center justify-center p-4">
      <div className="card w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="p-5 border-b border-[var(--border)] flex items-center justify-between">
          <h2 className="text-lg font-bold">
            {editing ? t("common.edit") : t("subscribers.addNew")}
          </h2>
          <button onClick={onClose} className="p-2 rounded hover:bg-[var(--bg-muted)]">
            <X className="w-4 h-4" />
          </button>
        </div>
        <form onSubmit={onSubmit} className="p-5 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Field label={t("subscribers.fullName")} required>
              <input
                name="fullName"
                defaultValue={editing?.fullName}
                className="input"
                required
              />
            </Field>
            <Field label={t("subscribers.phone")}>
              <input
                name="phone"
                defaultValue={editing?.phone || ""}
                className="input"
              />
            </Field>
            <Field label={t("subscribers.secondaryPhone")}>
              <input
                name="secondaryPhone"
                defaultValue={editing?.secondaryPhone || ""}
                className="input"
              />
            </Field>
            <Field label={t("subscribers.area")}>
              <input
                name="area"
                defaultValue={editing?.area || ""}
                className="input"
              />
            </Field>
            <Field label={t("common.address")} className="md:col-span-2">
              <input
                name="address"
                defaultValue={editing?.address || ""}
                className="input"
              />
            </Field>
            <Field label={t("subscribers.subscriptionType")}>
              <select
                name="subscriptionType"
                defaultValue={editing?.subscriptionType || "monthly"}
                className="input"
              >
                <option value="monthly">{t("subscribers.monthly")}</option>
                <option value="quarterly">{t("subscribers.quarterly")}</option>
                <option value="semi_annual">{t("subscribers.semi_annual")}</option>
                <option value="annual">{t("subscribers.annual")}</option>
              </select>
            </Field>
            <Field label={t("subscribers.monthlyFee")}>
              <input
                name="monthlyFee"
                type="number"
                step="0.01"
                defaultValue={editing?.monthlyFee || "0"}
                className="input"
                required
              />
            </Field>
            <Field label={t("subscribers.dueDate")}>
              <input
                name="dueDate"
                type="number"
                min="1"
                max="31"
                defaultValue={editing?.dueDate || "1"}
                className="input"
              />
            </Field>
            {editing && (
              <Field label={t("common.status")}>
                <select
                  name="status"
                  defaultValue={editing.status}
                  className="input"
                  onChange={async (e) => {
                    await updateSubscriber(editing.id, {
                      status: e.target.value as "active",
                    });
                    onSaved();
                  }}
                >
                  <option value="active">{t("subscribers.active")}</option>
                  <option value="expired">{t("subscribers.expired")}</option>
                  <option value="suspended">{t("subscribers.suspended")}</option>
                  <option value="cancelled">{t("subscribers.cancelled")}</option>
                </select>
              </Field>
            )}
            <Field label={t("common.notes")} className="md:col-span-2">
              <textarea
                name="notes"
                defaultValue={editing?.notes || ""}
                className="input"
                rows={3}
              />
            </Field>
          </div>
          {error && (
            <div className="bg-[color-mix(in_srgb,var(--danger)_10%,transparent)] text-[var(--danger)] rounded-lg p-3 text-sm">
              {error}
            </div>
          )}
          <div className="flex justify-end gap-2 pt-4 border-t border-[var(--border)]">
            <button type="button" onClick={onClose} className="btn btn-ghost">
              {t("common.cancel")}
            </button>
            <button type="submit" disabled={loading} className="btn btn-primary">
              {loading ? t("common.loading") : t("common.save")}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function Field({
  label,
  children,
  required,
  className,
}: {
  label: string;
  children: React.ReactNode;
  required?: boolean;
  className?: string;
}) {
  return (
    <div className={className}>
      <label className="block text-sm font-medium mb-1.5">
        {label}
        {required && <span className="text-[var(--danger)] ms-1">*</span>}
      </label>
      {children}
    </div>
  );
}
