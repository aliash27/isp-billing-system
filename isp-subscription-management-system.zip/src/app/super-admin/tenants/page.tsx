import { listAllTenants } from "@/app/super-admin/actions";
import { TenantsView } from "@/components/tenants-view";

export const dynamic = "force-dynamic";

export default async function TenantsPage() {
  const rows = await listAllTenants();
  return <TenantsView rows={rows} />;
}
