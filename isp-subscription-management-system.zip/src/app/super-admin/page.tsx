import { getSuperAdminOverview } from "@/app/super-admin/actions";
import { SuperAdminDashboard } from "@/components/super-admin-dashboard";

export const dynamic = "force-dynamic";

export default async function SuperAdminPage() {
  const data = await getSuperAdminOverview();
  return <SuperAdminDashboard data={data} />;
}
