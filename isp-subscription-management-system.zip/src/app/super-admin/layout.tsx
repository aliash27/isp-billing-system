import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";
import { SuperAdminShell } from "@/components/super-admin-shell";

export default async function SuperAdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getSession();
  if (!session) redirect("/login");
  if (session.role !== "super_admin") redirect("/dashboard");
  return <SuperAdminShell session={session}>{children}</SuperAdminShell>;
}
