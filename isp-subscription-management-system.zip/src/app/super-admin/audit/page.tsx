import { listAuditLogs } from "@/app/super-admin/actions";
import { AuditView } from "@/components/audit-view";

export const dynamic = "force-dynamic";

export default async function AuditPage() {
  const rows = await listAuditLogs(200);
  return <AuditView rows={rows} />;
}
