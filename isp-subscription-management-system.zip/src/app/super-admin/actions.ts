"use server";

import { db } from "@/db";
import {
  tenants,
  users,
  subscriptionPlans,
  subscribers,
  payments,
  auditLogs,
} from "@/db/schema";
import { requireSession, hashPassword, type SessionUser } from "@/lib/auth";
import { eq, desc, and, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { slugify } from "@/lib/utils";

async function audit(
  session: SessionUser,
  action: string,
  entity: string,
  entityId?: string,
  meta?: Record<string, unknown>
) {
  try {
    await db.insert(auditLogs).values({
      actorId: session.id,
      actorName: session.fullName,
      action,
      entity,
      entityId,
      meta,
    });
  } catch {
    /* ignore */
  }
}

export async function getSuperAdminOverview() {
  const session = await requireSession();
  if (session.role !== "super_admin") throw new Error("FORBIDDEN");

  const [tenantStats] = await db
    .select({
      total: sql<number>`count(*)::int`,
      active: sql<number>`count(*) filter (where status = 'active')::int`,
      trial: sql<number>`count(*) filter (where status = 'trial')::int`,
      expired: sql<number>`count(*) filter (where status = 'expired')::int`,
    })
    .from(tenants);

  const [userStats] = await db
    .select({
      total: sql<number>`count(*)::int`,
      pending: sql<number>`count(*) filter (where status = 'pending')::int`,
    })
    .from(users);

  const [subCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(subscribers);

  const [revenue] = await db
    .select({ total: sql<string>`coalesce(sum(amount::numeric), 0)::text` })
    .from(payments);

  const recentTenants = await db
    .select()
    .from(tenants)
    .orderBy(desc(tenants.createdAt))
    .limit(5);

  const pendingUsers = await db
    .select({
      user: users,
      tenant: tenants,
    })
    .from(users)
    .leftJoin(tenants, eq(users.tenantId, tenants.id))
    .where(eq(users.status, "pending"))
    .orderBy(desc(users.createdAt))
    .limit(10);

  const plans = await db.select().from(subscriptionPlans).orderBy(subscriptionPlans.durationDays);

  return {
    tenantStats: tenantStats || { total: 0, active: 0, trial: 0, expired: 0 },
    userStats: userStats || { total: 0, pending: 0 },
    totalSubscribers: subCount?.count || 0,
    globalRevenue: revenue?.total || "0",
    recentTenants,
    pendingUsers,
    plans,
  };
}

export async function listAllTenants() {
  const session = await requireSession();
  if (session.role !== "super_admin") throw new Error("FORBIDDEN");
  return db.select().from(tenants).orderBy(desc(tenants.createdAt));
}

export async function createTenant(data: {
  name: string;
  slug?: string;
  email: string;
  password: string;
  phone?: string;
  address?: string;
  planCode: string;
  trialDays: number;
}) {
  const session = await requireSession();
  if (session.role !== "super_admin") throw new Error("FORBIDDEN");

  const slug = data.slug ? slugify(data.slug) : slugify(data.name);
  const [plan] = await db
    .select()
    .from(subscriptionPlans)
    .where(eq(subscriptionPlans.code, data.planCode as "monthly"))
    .limit(1);
  if (!plan) throw new Error("PLAN_NOT_FOUND");

  const starts = new Date();
  const ends = new Date();
  ends.setDate(ends.getDate() + plan.durationDays);
  const trialEnds = new Date();
  trialEnds.setDate(trialEnds.getDate() + data.trialDays);

  const [tenant] = await db
    .insert(tenants)
    .values({
      name: data.name,
      slug,
      email: data.email,
      phone: data.phone,
      address: data.address,
      status: data.trialDays > 0 ? "trial" : "active",
      subscriptionPlanId: plan.id,
      subscriptionStartsAt: starts,
      subscriptionEndsAt: ends,
      trialEndsAt: data.trialDays > 0 ? trialEnds : null,
    })
    .returning();

  const pwHash = await hashPassword(data.password);
  await db.insert(users).values({
    tenantId: tenant.id,
    role: "admin",
    fullName: data.name + " Admin",
    email: data.email,
    passwordHash: pwHash,
    status: "active",
  });

  await audit(session, "create", "tenant", tenant.id, { name: data.name });
  revalidatePath("/super-admin");
  return tenant;
}

export async function updateTenantStatus(
  id: string,
  status: "active" | "suspended" | "expired"
) {
  const session = await requireSession();
  if (session.role !== "super_admin") throw new Error("FORBIDDEN");

  await db
    .update(tenants)
    .set({ status, readMode: status === "expired", updatedAt: new Date() })
    .where(eq(tenants.id, id));

  await audit(session, "update_status", "tenant", id, { status });
  revalidatePath("/super-admin");
}

export async function renewTenant(id: string, planCode: string) {
  const session = await requireSession();
  if (session.role !== "super_admin") throw new Error("FORBIDDEN");

  const [plan] = await db
    .select()
    .from(subscriptionPlans)
    .where(eq(subscriptionPlans.code, planCode as "monthly"))
    .limit(1);
  if (!plan) throw new Error("PLAN_NOT_FOUND");

  const now = new Date();
  const ends = new Date(now);
  ends.setDate(ends.getDate() + plan.durationDays);

  await db
    .update(tenants)
    .set({
      status: "active",
      readMode: false,
      subscriptionPlanId: plan.id,
      subscriptionStartsAt: now,
      subscriptionEndsAt: ends,
      updatedAt: new Date(),
    })
    .where(eq(tenants.id, id));

  await audit(session, "renew", "tenant", id, { planCode });
  revalidatePath("/super-admin");
}

export async function approveUser(userId: string) {
  const session = await requireSession();
  if (session.role !== "super_admin") throw new Error("FORBIDDEN");

  await db
    .update(users)
    .set({ status: "active", approvedAt: new Date(), approvedBy: session.id })
    .where(eq(users.id, userId));

  await audit(session, "approve", "user", userId);
  revalidatePath("/super-admin");
}

export async function suspendUser(userId: string) {
  const session = await requireSession();
  if (session.role !== "super_admin") throw new Error("FORBIDDEN");

  await db
    .update(users)
    .set({ status: "suspended" })
    .where(eq(users.id, userId));
  await audit(session, "suspend", "user", userId);
  revalidatePath("/super-admin");
}

export async function lockExpiredTenants() {
  const session = await requireSession();
  if (session.role !== "super_admin") throw new Error("FORBIDDEN");

  const now = new Date();
  const expired = await db
    .select()
    .from(tenants)
    .where(
      and(
        sql`${tenants.subscriptionEndsAt} < ${now.toISOString()}`,
        sql`${tenants.status} in ('active', 'trial')`
      )
    );

  for (const t of expired) {
    await db
      .update(tenants)
      .set({ status: "expired", readMode: true, updatedAt: new Date() })
      .where(eq(tenants.id, t.id));
  }

  await audit(session, "lock_expired", "tenants", undefined, {
    count: expired.length,
  });
  revalidatePath("/super-admin");
  return { count: expired.length };
}

export async function updatePlan(
  id: string,
  data: { name?: string; price?: string; durationDays?: number }
) {
  const session = await requireSession();
  if (session.role !== "super_admin") throw new Error("FORBIDDEN");

  await db.update(subscriptionPlans).set(data).where(eq(subscriptionPlans.id, id));
  await audit(session, "update", "plan", id, data as Record<string, unknown>);
  revalidatePath("/super-admin");
}

export async function listAuditLogs(limit = 50) {
  const session = await requireSession();
  if (session.role !== "super_admin") throw new Error("FORBIDDEN");

  return db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(limit);
}
