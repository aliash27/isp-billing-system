"use client";

import { useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useApp } from "@/components/providers";
import { Wifi, Mail, Lock, Loader2, Globe, Moon, Sun } from "lucide-react";

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><div className="spinner" /></div>}>
      <LoginInner />
    </Suspense>
  );
}

function LoginInner() {
  const { t, lang, setLang, theme, setTheme } = useApp();
  const router = useRouter();
  const sp = useSearchParams();
  const redirect = sp.get("redirect") || "";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error === "invalid" ? t("auth.invalid") : t("auth.locked"));
        return;
      }
      router.push(data.redirect || redirect || "/dashboard");
      router.refresh();
    } catch {
      setError(t("messages.error"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left panel - branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-primary relative overflow-hidden items-center justify-center p-12">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-10 left-10 w-72 h-72 bg-white/20 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-white/10 rounded-full blur-3xl" />
        </div>
        <div className="relative z-10 text-white max-w-lg">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-14 h-14 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center">
              <Wifi className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">ISP Billing</h1>
              <p className="text-sm opacity-80">SaaS Management Platform</p>
            </div>
          </div>
          <h2 className="text-4xl font-bold leading-tight mb-4">
            {t("app.tagline")}
          </h2>
          <p className="text-lg opacity-90 leading-relaxed">
            {lang === "ar"
              ? "منصة متكاملة لإدارة اشتراكات العملاء، تحصيل المدفوعات، ومتابعة الديون. مصممة لمزودي خدمة الإنترنت."
              : "A complete platform to manage customer subscriptions, collect payments, and track debts. Built for Internet Service Providers."}
          </p>
          <div className="mt-10 grid grid-cols-3 gap-4">
            {[
              { n: "10K+", l: lang === "ar" ? "مشترك" : "Subscribers" },
              { n: "99.9%", l: lang === "ar" ? "وقت التشغيل" : "Uptime" },
              { n: "24/7", l: lang === "ar" ? "دعم" : "Support" },
            ].map((s) => (
              <div key={s.l} className="bg-white/10 backdrop-blur rounded-xl p-4 border border-white/20">
                <div className="text-2xl font-bold">{s.n}</div>
                <div className="text-sm opacity-80">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel - form */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12 bg-[var(--bg)]">
        <div className="w-full max-w-md fade-in">
          <div className="flex justify-between items-center mb-8">
            <div className="lg:hidden flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center text-white">
                <Wifi className="w-5 h-5" />
              </div>
              <span className="font-bold text-lg">ISP Billing</span>
            </div>
            <div className="flex items-center gap-2 ms-auto">
              <button
                onClick={() => setLang(lang === "ar" ? "en" : "ar")}
                className="btn btn-ghost !p-2"
                title="Language"
              >
                <Globe className="w-4 h-4" />
                <span className="text-xs font-medium">
                  {lang === "ar" ? "EN" : "ع"}
                </span>
              </button>
              <button
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                className="btn btn-ghost !p-2"
                title="Theme"
              >
                {theme === "dark" ? (
                  <Sun className="w-4 h-4" />
                ) : (
                  <Moon className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>

          <h1 className="text-3xl font-bold mb-2">{t("auth.welcome")}</h1>
          <p className="text-[var(--text-muted)] mb-8">{t("auth.subtitle")}</p>

          <form onSubmit={onSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                {t("auth.email")}
              </label>
              <div className="relative">
                <Mail className="absolute top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-muted)] start-3" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="input ps-10"
                  placeholder="admin@demo-net.local"
                  required
                  autoFocus
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">
                {t("auth.password")}
              </label>
              <div className="relative">
                <Lock className="absolute top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-muted)] start-3" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="input ps-10"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="bg-[color-mix(in_srgb,var(--danger)_10%,transparent)] text-[var(--danger)] border border-[color-mix(in_srgb,var(--danger)_30%,transparent)] rounded-lg p-3 text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="btn btn-primary w-full"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                t("auth.loginBtn")
              )}
            </button>
          </form>

          <div className="mt-8 card p-4">
            <p className="text-xs text-[var(--text-muted)] mb-2 font-medium">
              {lang === "ar" ? "حسابات تجريبية" : "Demo Accounts"}
            </p>
            <div className="space-y-1 text-xs font-mono">
              <div>
                <span className="badge badge-info me-2">Super</span>
                super@isp.local / admin123
              </div>
              <div>
                <span className="badge badge-success me-2">Admin</span>
                admin@demo-net.local / admin123
              </div>
              <div>
                <span className="badge badge-warning me-2">Acct</span>
                accountant@demo-net.local / admin123
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
