import { listSubscribers } from "@/app/actions";
import { SubscribersView } from "@/components/subscribers-view";

export const dynamic = "force-dynamic";

export default async function SubscribersPage(props: {
  searchParams: Promise<{ q?: string; status?: string; page?: string }>;
}) {
  const sp = await props.searchParams;
  const data = await listSubscribers({
    q: sp.q,
    status: sp.status,
    page: sp.page ? parseInt(sp.page) : 1,
  });
  return <SubscribersView initial={data} searchParams={sp} />;
}
