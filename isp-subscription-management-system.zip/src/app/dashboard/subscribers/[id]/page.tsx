import { getSubscriber } from "@/app/actions";
import { redirect } from "next/navigation";
import { SubscriberDetail } from "@/components/subscriber-detail";

export const dynamic = "force-dynamic";

export default async function SubscriberDetailPage(props: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await props.params;
  const data = await getSubscriber(id);
  if (!data) redirect("/dashboard/subscribers");
  return <SubscriberDetail data={data} />;
}
