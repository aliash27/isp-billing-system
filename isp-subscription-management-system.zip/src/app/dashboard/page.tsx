import { getDashboardStats } from "@/app/actions";
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";
import { DashboardView } from "@/components/dashboard-view";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const session = await getSession();
  if (!session) redirect("/login");
  const data = await getDashboardStats();
  return <DashboardView data={data} session={session} />;
}
