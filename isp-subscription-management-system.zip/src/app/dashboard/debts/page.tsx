import { listDebtors } from "@/app/actions";
import { DebtsView } from "@/components/debts-view";

export const dynamic = "force-dynamic";

export default async function DebtsPage() {
  const rows = await listDebtors();
  return <DebtsView rows={rows} />;
}
