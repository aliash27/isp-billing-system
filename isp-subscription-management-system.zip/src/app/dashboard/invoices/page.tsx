import { listInvoices } from "@/app/actions";
import { InvoicesView } from "@/components/invoices-view";

export const dynamic = "force-dynamic";

export default async function InvoicesPage() {
  const rows = await listInvoices();
  return <InvoicesView rows={rows} />;
}
