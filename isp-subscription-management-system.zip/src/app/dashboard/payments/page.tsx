import { listPayments, listSubscribers } from "@/app/actions";
import { PaymentsView } from "@/components/payments-view";

export const dynamic = "force-dynamic";

export default async function PaymentsPage(props: {
  searchParams: Promise<{ q?: string; from?: string; to?: string; page?: string }>;
}) {
  const sp = await props.searchParams;
  const data = await listPayments({
    q: sp.q,
    from: sp.from,
    to: sp.to,
    page: sp.page ? parseInt(sp.page) : 1,
  });
  const subs = await listSubscribers({ page: 1 });
  return <PaymentsView initial={data} subscribers={subs.rows} searchParams={sp} />;
}
