import { getTenantSettings } from "@/app/actions";
import { SettingsView } from "@/components/settings-view";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const data = await getTenantSettings();
  return <SettingsView initial={data} />;
}
