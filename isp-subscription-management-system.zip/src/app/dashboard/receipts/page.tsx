import { listReceipts } from "@/app/actions";
import { ReceiptsView } from "@/components/receipts-view";

export const dynamic = "force-dynamic";

export default async function ReceiptsPage(props: {
  searchParams: Promise<{ q?: string; page?: string }>;
}) {
  const sp = await props.searchParams;
  const data = await listReceipts({
    q: sp.q,
    page: sp.page ? parseInt(sp.page) : 1,
  });
  return <ReceiptsView initial={data} />;
}
