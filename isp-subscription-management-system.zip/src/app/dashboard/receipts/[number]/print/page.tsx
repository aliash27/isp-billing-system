import { getReceipt } from "@/app/actions";
import { redirect } from "next/navigation";
import { ReceiptPrint } from "@/components/receipt-print";

export const dynamic = "force-dynamic";

export default async function ReceiptPrintPage(props: {
  params: Promise<{ number: string }>;
}) {
  const { number } = await props.params;
  const data = await getReceipt(decodeURIComponent(number));
  if (!data) redirect("/dashboard/receipts");
  return <ReceiptPrint data={data} />;
}
