import type { ReactNode } from "react";
import type { Metadata } from "next";
import "./globals.css";
import { ClientProviders } from "@/components/providers";

export const metadata: Metadata = {
  title: "ISP Billing — Subscription & Collection",
  description:
    "Multi-tenant SaaS ISP Subscription Collection and Debt Management System",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head>
        <meta name="theme-color" content="#0ea5e9" />
        <link
          rel="preconnect"
          href="https://fonts.googleapis.com"
        />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Tajawal:wght@400;500;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="antialiased">
        <ClientProviders>{children}</ClientProviders>
      </body>
    </html>
  );
}
