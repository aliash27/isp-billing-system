import { NextResponse } from "next/server";
import { seedDatabase } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function POST() {
  if (process.env.NODE_ENV === "production" && process.env.ALLOW_SEED !== "1") {
    return NextResponse.json({ error: "disabled" }, { status: 403 });
  }
  try {
    const res = await seedDatabase();
    return NextResponse.json(res);
  } catch (e) {
    return NextResponse.json(
      { error: (e as Error).message },
      { status: 500 }
    );
  }
}
