import { NextResponse } from "next/server";
import { signIn, setSessionCookie } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const { email, password } = await req.json();
    if (!email || !password) {
      return NextResponse.json(
        { error: "invalid", message: "Email and password required" },
        { status: 400 }
      );
    }
    const result = await signIn(email, password);
    if ("error" in result) {
      return NextResponse.json({ error: result.error }, { status: 401 });
    }
    await setSessionCookie(result.token);
    return NextResponse.json({
      user: result.user,
      redirect:
        result.user.role === "super_admin" ? "/super-admin" : "/dashboard",
    });
  } catch (e) {
    return NextResponse.json(
      { error: "server", message: (e as Error).message },
      { status: 500 }
    );
  }
}
