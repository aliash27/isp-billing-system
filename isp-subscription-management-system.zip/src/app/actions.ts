"use server";

import { db } from "@/db";
import {
  subscribers,
  payments,
  debts,
  invoices,
  receiptTemplates,
  users,
  tenants,
  auditLogs,
} from "@/db/schema";
import { requireSession, requireTenant, type SessionUser } from "@/lib/auth";
import { eq, desc, and, like, sql, or, gte, lte } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { generateReceiptNumber } from "@/lib/utils";

// -------------------- Audit helper --------------------
async function audit(
  session: SessionUser,
  action: string,
  entity: string,
  entityId?: string,
  meta?: Record<string, unknown>
) {
  try {
    await db.insert(auditLogs).values({
      tenantId: session.tenantId,
      actorId: session.id,
      actorName: session.fullName,
      action,
      entity,
      entityId,
      meta,
    });
  } catch {
    /* ignore */
  }
}

// -------------------- Dashboard --------------------
export async function getDashboardStats() {
  const session = await requireSession();
  const tenantId = requireTenant(session);

  const [subs] = await db
    .select({
      total: sql<number>`count(*)::int`,
      active: sql<number>`count(*) filter (where status = 'active')::int`,
      expired: sql<number>`count(*) filter (where status = 'expired')::int`,
      totalDebt: sql<string>`coalesce(sum(debt_amount::numeric), 0)::text`,
    })
    .from(subscribers)
    .where(eq(subscribers.tenantId, tenantId));

  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);
  const monthEnd = new Date(monthStart);
  monthEnd.setMonth(monthEnd.getMonth() + 1);

  const [revenue] = await db
    .select({
      total: sql<string>`coalesce(sum(amount::numeric), 0)::text`,
      count: sql<number>`count(*)::int`,
    })
    .from(payments)
    .where(
      and(
        eq(payments.tenantId, tenantId),
        gte(payments.paidAt, monthStart),
        lte(payments.paidAt, monthEnd)
      )
    );

  const recentPayments = await db
    .select({
      id: payments.id,
      receiptNumber: payments.receiptNumber,
      amount: payments.amount,
      method: payments.method,
      paidAt: payments.paidAt,
      subscriberName: subscribers.fullName,
    })
    .from(payments)
    .innerJoin(subscribers, eq(payments.subscriberId, subscribers.id))
    .where(eq(payments.tenantId, tenantId))
    .orderBy(desc(payments.paidAt))
    .limit(6);

  // Revenue by month (last 6 months)
  const months: { month: string; revenue: number; count: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const start = new Date();
    start.setDate(1);
    start.setMonth(start.getMonth() - i);
    start.setHours(0, 0, 0, 0);
    const end = new Date(start);
    end.setMonth(end.getMonth() + 1);
    const [r] = await db
      .select({
        revenue: sql<string>`coalesce(sum(amount::numeric), 0)::text`,
        count: sql<number>`count(*)::int`,
      })
      .from(payments)
      .where(
        and(
          eq(payments.tenantId, tenantId),
          gte(payments.paidAt, start),
          lte(payments.paidAt, end)
        )
      );
    months.push({
      month: start.toLocaleDateString("en", { month: "short" }),
      revenue: parseFloat(r?.revenue || "0"),
      count: r?.count || 0,
    });
  }

  // Subscription type breakdown
  const breakdown = await db
    .select({
      type: subscribers.subscriptionType,
      count: sql<number>`count(*)::int`,
    })
    .from(subscribers)
    .where(
      and(eq(subscribers.tenantId, tenantId), eq(subscribers.status, "active"))
    )
    .groupBy(subscribers.subscriptionType);

  // Expiring in next 7 days
  const now = new Date();
  const soon = new Date();
  soon.setDate(soon.getDate() + 7);
  const expiring = await db
    .select({
      id: subscribers.id,
      fullName: subscribers.fullName,
      nextBillingAt: subscribers.nextBillingAt,
      phone: subscribers.phone,
    })
    .from(subscribers)
    .where(
      and(
        eq(subscribers.tenantId, tenantId),
        eq(subscribers.status, "active"),
        gte(subscribers.nextBillingAt, now),
        lte(subscribers.nextBillingAt, soon)
      )
    )
    .orderBy(subscribers.nextBillingAt)
    .limit(5);

  return {
    stats: {
      total: subs?.total ?? 0,
      active: subs?.active ?? 0,
      expired: subs?.expired ?? 0,
      totalDebt: subs?.totalDebt ?? "0",
      monthlyRevenue: revenue?.total ?? "0",
      monthlyCount: revenue?.count ?? 0,
    },
    recentPayments,
    revenueByMonth: months,
    subscriptionBreakdown: breakdown,
    expiringSoon: expiring,
  };
}

// -------------------- Subscribers --------------------
export async function listSubscribers(opts: {
  q?: string;
  status?: string;
  page?: number;
}) {
  const session = await requireSession();
  const tenantId = requireTenant(session);
  const page = opts.page ?? 1;
  const limit = 25;
  const offset = (page - 1) * limit;

  const conds = [eq(subscribers.tenantId, tenantId)];
  if (opts.status && opts.status !== "all") {
    conds.push(eq(subscribers.status, opts.status as "active"));
  }
  if (opts.q && opts.q.trim()) {
    conds.push(
      or(
        like(subscribers.fullName, `%${opts.q}%`),
        like(subscribers.phone, `%${opts.q}%`)
      )!
    );
  }

  const where = and(...conds);
  const rows = await db
    .select()
    .from(subscribers)
    .where(where)
    .orderBy(desc(subscribers.createdAt))
    .limit(limit)
    .offset(offset);

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(subscribers)
    .where(where);

  return { rows, total: count ?? 0, page, pages: Math.ceil((count ?? 0) / limit) };
}

export async function getSubscriber(id: string) {
  const session = await requireSession();
  const tenantId = requireTenant(session);
  const [row] = await db
    .select()
    .from(subscribers)
    .where(and(eq(subscribers.id, id), eq(subscribers.tenantId, tenantId)))
    .limit(1);
  if (!row) return null;

  const payList = await db
    .select()
    .from(payments)
    .where(eq(payments.subscriberId, id))
    .orderBy(desc(payments.paidAt))
    .limit(50);

  const debtList = await db
    .select()
    .from(debts)
    .where(eq(debts.subscriberId, id))
    .orderBy(desc(debts.createdAt))
    .limit(50);

  return { subscriber: row, payments: payList, debts: debtList };
}

export async function createSubscriber(data: {
  fullName: string;
  phone?: string;
  secondaryPhone?: string;
  address?: string;
  area?: string;
  subscriptionType: "monthly" | "quarterly" | "semi_annual" | "annual";
  monthlyFee: string;
  dueDate?: string;
  notes?: string;
}) {
  const session = await requireSession();
  const tenantId = requireTenant(session);
  if (session.readMode) throw new Error("READONLY");
  if (session.role !== "admin") throw new Error("FORBIDDEN");

  const next = new Date();
  next.setDate(parseInt(data.dueDate || "1", 10));
  if (next.getTime() < Date.now()) next.setMonth(next.getMonth() + 1);

  const [created] = await db
    .insert(subscribers)
    .values({
      tenantId,
      fullName: data.fullName,
      phone: data.phone,
      secondaryPhone: data.secondaryPhone,
      address: data.address,
      area: data.area,
      subscriptionType: data.subscriptionType,
      monthlyFee: data.monthlyFee,
      dueDate: data.dueDate || "1",
      debtAmount: "0",
      status: "active",
      nextBillingAt: next,
      notes: data.notes,
      createdBy: session.id,
    })
    .returning();

  await audit(session, "create", "subscriber", created.id, {
    name: created.fullName,
  });
  revalidatePath("/dashboard/subscribers");
  return created;
}

export async function updateSubscriber(
  id: string,
  data: Partial<{
    fullName: string;
    phone: string;
    secondaryPhone: string;
    address: string;
    area: string;
    subscriptionType: "monthly" | "quarterly" | "semi_annual" | "annual";
    monthlyFee: string;
    dueDate: string;
    status: "active" | "expired" | "suspended" | "cancelled";
    notes: string;
  }>
) {
  const session = await requireSession();
  const tenantId = requireTenant(session);
  if (session.readMode && data.status !== undefined) throw new Error("READONLY");

  await db
    .update(subscribers)
    .set({ ...data, updatedAt: new Date() })
    .where(and(eq(subscribers.id, id), eq(subscribers.tenantId, tenantId)));

  await audit(session, "update", "subscriber", id, data as Record<string, unknown>);
  revalidatePath("/dashboard/subscribers");
  revalidatePath(`/dashboard/subscribers/${id}`);
}

export async function deleteSubscriber(id: string) {
  const session = await requireSession();
  const tenantId = requireTenant(session);
  if (session.readMode) throw new Error("READONLY");
  if (session.role !== "admin") throw new Error("FORBIDDEN");

  await db
    .delete(subscribers)
    .where(and(eq(subscribers.id, id), eq(subscribers.tenantId, tenantId)));
  await audit(session, "delete", "subscriber", id);
  revalidatePath("/dashboard/subscribers");
}

// -------------------- Payments --------------------
export async function listPayments(opts: {
  q?: string;
  from?: string;
  to?: string;
  page?: number;
}) {
  const session = await requireSession();
  const tenantId = requireTenant(session);
  const page = opts.page ?? 1;
  const limit = 25;
  const offset = (page - 1) * limit;

  const conds = [eq(payments.tenantId, tenantId)];
  if (opts.q) {
    conds.push(
      or(
        like(payments.receiptNumber, `%${opts.q}%`),
        like(subscribers.fullName, `%${opts.q}%`)
      )!
    );
  }
  if (opts.from) conds.push(gte(payments.paidAt, new Date(opts.from)));
  if (opts.to) {
    const to = new Date(opts.to);
    to.setHours(23, 59, 59, 999);
    conds.push(lte(payments.paidAt, to));
  }

  const where = and(...conds);
  const rows = await db
    .select({
      payment: payments,
      subscriber: {
        id: subscribers.id,
        fullName: subscribers.fullName,
        phone: subscribers.phone,
      },
    })
    .from(payments)
    .innerJoin(subscribers, eq(payments.subscriberId, subscribers.id))
    .where(where)
    .orderBy(desc(payments.paidAt))
    .limit(limit)
    .offset(offset);

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(payments)
    .innerJoin(subscribers, eq(payments.subscriberId, subscribers.id))
    .where(where);

  return { rows, total: count ?? 0, page, pages: Math.ceil((count ?? 0) / limit) };
}

export async function createPayment(data: {
  subscriberId: string;
  amount: string;
  method: "cash" | "card" | "transfer" | "check" | "other";
  type: "subscription" | "debt" | "advance" | "refund";
  monthsCovered: string;
  note?: string;
  paidAt?: string;
}) {
  const session = await requireSession();
  const tenantId = requireTenant(session);
  if (session.readMode) throw new Error("READONLY");
  if (session.role === "accountant" && !["cash", "card", "transfer"].includes(data.method)) {
    throw new Error("FORBIDDEN");
  }

  const [sub] = await db
    .select()
    .from(subscribers)
    .where(
      and(eq(subscribers.id, data.subscriberId), eq(subscribers.tenantId, tenantId))
    )
    .limit(1);
  if (!sub) throw new Error("NOT_FOUND");

  const receiptNumber = generateReceiptNumber();
  const paidAt = data.paidAt ? new Date(data.paidAt) : new Date();

  const [payment] = await db
    .insert(payments)
    .values({
      tenantId,
      subscriberId: data.subscriberId,
      receiptNumber,
      amount: data.amount,
      method: data.method,
      type: data.type,
      monthsCovered: data.monthsCovered || "1",
      note: data.note,
      paidAt,
      receivedBy: session.id,
    })
    .returning();

  // Update debt tracking
  const amount = parseFloat(data.amount);
  if (data.type === "debt") {
    const newDebt = Math.max(0, parseFloat(sub.debtAmount) - amount);
    await db
      .update(subscribers)
      .set({ debtAmount: String(newDebt), updatedAt: new Date() })
      .where(eq(subscribers.id, data.subscriberId));
  } else if (data.type === "subscription") {
    // Advance next billing
    const months = parseFloat(data.monthsCovered) || 1;
    const next = sub.nextBillingAt || new Date();
    next.setMonth(next.getMonth() + Math.ceil(months));
    await db
      .update(subscribers)
      .set({
        nextBillingAt: next,
        status: "active",
        updatedAt: new Date(),
      })
      .where(eq(subscribers.id, data.subscriberId));
  }

  // Debt ledger entry
  await db.insert(debts).values({
    tenantId,
    subscriberId: data.subscriberId,
    paymentId: payment.id,
    amount: data.amount,
    remaining: "0",
    type: "payment",
    description: data.note || data.type,
  });

  await audit(session, "create", "payment", payment.id, {
    receiptNumber,
    amount: data.amount,
    subscriber: sub.fullName,
  });

  revalidatePath("/dashboard/payments");
  revalidatePath("/dashboard/receipts");
  revalidatePath("/dashboard/subscribers");
  revalidatePath("/dashboard");
  return { payment, receiptNumber };
}

export async function deletePayment(id: string) {
  const session = await requireSession();
  const tenantId = requireTenant(session);
  if (session.role !== "admin") throw new Error("FORBIDDEN");

  await db
    .delete(payments)
    .where(and(eq(payments.id, id), eq(payments.tenantId, tenantId)));
  await audit(session, "delete", "payment", id);
  revalidatePath("/dashboard/payments");
}

// -------------------- Receipts --------------------
export async function listReceipts(opts: { q?: string; page?: number }) {
  return listPayments(opts);
}

export async function getReceipt(receiptNumber: string) {
  const session = await requireSession();
  const tenantId = requireTenant(session);

  const [row] = await db
    .select({
      payment: payments,
      subscriber: subscribers,
    })
    .from(payments)
    .innerJoin(subscribers, eq(payments.subscriberId, subscribers.id))
    .where(
      and(
        eq(payments.receiptNumber, receiptNumber),
        eq(payments.tenantId, tenantId)
      )
    )
    .limit(1);
  if (!row) return null;

  const [tenant] = await db
    .select()
    .from(tenants)
    .where(eq(tenants.id, tenantId))
    .limit(1);

  const [template] = await db
    .select()
    .from(receiptTemplates)
    .where(eq(receiptTemplates.tenantId, tenantId))
    .limit(1);

  return {
    payment: row.payment,
    subscriber: row.subscriber,
    tenant,
    template,
  };
}

// -------------------- Reports --------------------
export async function getReport(type: string, opts: { from?: string; to?: string }) {
  const session = await requireSession();
  const tenantId = requireTenant(session);

  const from = opts.from ? new Date(opts.from) : new Date(Date.now() - 30 * 86400000);
  const to = opts.to ? new Date(opts.to) : new Date();
  to.setHours(23, 59, 59, 999);

  if (type === "daily") {
    return db
      .select({
        date: sql<string>`to_char(${payments.paidAt}, 'YYYY-MM-DD')`,
        total: sql<string>`coalesce(sum(amount::numeric), 0)::text`,
        count: sql<number>`count(*)::int`,
      })
      .from(payments)
      .where(
        and(
          eq(payments.tenantId, tenantId),
          gte(payments.paidAt, from),
          lte(payments.paidAt, to)
        )
      )
      .groupBy(sql`to_char(${payments.paidAt}, 'YYYY-MM-DD')`)
      .orderBy(sql`to_char(${payments.paidAt}, 'YYYY-MM-DD')`);
  }

  if (type === "monthly") {
    return db
      .select({
        month: sql<string>`to_char(${payments.paidAt}, 'YYYY-MM')`,
        total: sql<string>`coalesce(sum(amount::numeric), 0)::text`,
        count: sql<number>`count(*)::int`,
      })
      .from(payments)
      .where(
        and(
          eq(payments.tenantId, tenantId),
          gte(payments.paidAt, from),
          lte(payments.paidAt, to)
        )
      )
      .groupBy(sql`to_char(${payments.paidAt}, 'YYYY-MM')`)
      .orderBy(sql`to_char(${payments.paidAt}, 'YYYY-MM')`);
  }

  if (type === "debtors") {
    return db
      .select()
      .from(subscribers)
      .where(
        and(
          eq(subscribers.tenantId, tenantId),
          sql`${subscribers.debtAmount}::numeric > 0`
        )
      )
      .orderBy(desc(subscribers.debtAmount));
  }

  if (type === "expiring") {
    const soon = new Date();
    soon.setDate(soon.getDate() + 30);
    return db
      .select()
      .from(subscribers)
      .where(
        and(
          eq(subscribers.tenantId, tenantId),
          eq(subscribers.status, "active"),
          lte(subscribers.nextBillingAt, soon)
        )
      )
      .orderBy(subscribers.nextBillingAt);
  }

  if (type === "accountants") {
    return db
      .select({
        userId: users.id,
        fullName: users.fullName,
        totalPayments: sql<number>`count(${payments.id})::int`,
        totalAmount: sql<string>`coalesce(sum(${payments.amount}::numeric), 0)::text`,
      })
      .from(users)
      .leftJoin(payments, eq(payments.receivedBy, users.id))
      .where(
        and(eq(users.tenantId, tenantId), eq(users.role, "accountant"))
      )
      .groupBy(users.id, users.fullName);
  }

  return [];
}

// -------------------- Invoices --------------------
export async function listInvoices() {
  const session = await requireSession();
  const tenantId = requireTenant(session);
  return db
    .select({
      invoice: invoices,
      subscriber: { id: subscribers.id, fullName: subscribers.fullName },
    })
    .from(invoices)
    .innerJoin(subscribers, eq(invoices.subscriberId, subscribers.id))
    .where(eq(invoices.tenantId, tenantId))
    .orderBy(desc(invoices.issuedAt))
    .limit(50);
}

// -------------------- Debts --------------------
export async function listDebtors() {
  const session = await requireSession();
  const tenantId = requireTenant(session);
  return db
    .select()
    .from(subscribers)
    .where(
      and(
        eq(subscribers.tenantId, tenantId),
        sql`${subscribers.debtAmount}::numeric > 0`
      )
    )
    .orderBy(desc(subscribers.debtAmount))
    .limit(100);
}

// -------------------- Settings --------------------
export async function getTenantSettings() {
  const session = await requireSession();
  const tenantId = requireTenant(session);
  const [tenant] = await db
    .select()
    .from(tenants)
    .where(eq(tenants.id, tenantId))
    .limit(1);
  const [template] = await db
    .select()
    .from(receiptTemplates)
    .where(eq(receiptTemplates.tenantId, tenantId))
    .limit(1);
  return { tenant, template };
}

export async function updateTenantSettings(data: {
  name?: string;
  phone?: string;
  email?: string;
  address?: string;
  currency?: string;
  locale?: string;
}) {
  const session = await requireSession();
  const tenantId = requireTenant(session);
  if (session.role !== "admin") throw new Error("FORBIDDEN");
  await db
    .update(tenants)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(tenants.id, tenantId));
  await audit(session, "update", "tenant", tenantId, data as Record<string, unknown>);
  revalidatePath("/dashboard/settings");
}

export async function updateReceiptTemplate(data: {
  headerTitle?: string;
  footerText?: string;
  accentColor?: string;
  thankYouMessage?: string;
  showLogo?: boolean;
  showPhone?: boolean;
  showAddress?: boolean;
}) {
  const session = await requireSession();
  const tenantId = requireTenant(session);
  if (session.role !== "admin") throw new Error("FORBIDDEN");

  const [existing] = await db
    .select()
    .from(receiptTemplates)
    .where(eq(receiptTemplates.tenantId, tenantId))
    .limit(1);

  if (existing) {
    await db
      .update(receiptTemplates)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(receiptTemplates.tenantId, tenantId));
  } else {
    await db.insert(receiptTemplates).values({ tenantId, ...data });
  }
  revalidatePath("/dashboard/settings");
}
