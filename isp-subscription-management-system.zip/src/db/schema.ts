import {
  pgTable,
  text,
  timestamp,
  boolean,
  integer,
  numeric,
  uuid,
  jsonb,
  index,
  unique,
} from "drizzle-orm/pg-core";

// ---------------------------------------------------------------------------
// Tenants (Admin Companies) - the multi-tenant root
// ---------------------------------------------------------------------------
export const tenants = pgTable(
  "tenants",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull(),
    slug: text("slug").notNull().unique(),
    logoUrl: text("logo_url"),
    phone: text("phone"),
    email: text("email"),
    address: text("address"),
    country: text("country").default("SA"),
    currency: text("currency").default("SAR"),
    locale: text("locale").default("ar"),
    timezone: text("timezone").default("Asia/Riyadh"),
    status: text("status", {
      enum: ["active", "suspended", "expired", "trial"],
    })
      .notNull()
      .default("trial"),
    subscriptionPlanId: uuid("subscription_plan_id"),
    subscriptionStartsAt: timestamp("subscription_starts_at"),
    subscriptionEndsAt: timestamp("subscription_ends_at"),
    trialEndsAt: timestamp("trial_ends_at"),
    readMode: boolean("read_mode").default(false),
    settings: jsonb("settings").$type<Record<string, unknown>>().default({}),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => ({
    slugIdx: index("tenants_slug_idx").on(t.slug),
    statusIdx: index("tenants_status_idx").on(t.status),
  })
);

// ---------------------------------------------------------------------------
// Subscription plans (managed by Super Admin, global)
// ---------------------------------------------------------------------------
export const subscriptionPlans = pgTable("subscription_plans", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  code: text("code", {
    enum: ["trial", "monthly", "quarterly", "semi_annual", "annual"],
  }).notNull(),
  durationDays: integer("duration_days").notNull(),
  price: numeric("price", { precision: 12, scale: 2 }).notNull(),
  features: jsonb("features").$type<string[]>().default([]),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------------------------------------------------------------------------
// Users (super_admin, admin, accountant)
// ---------------------------------------------------------------------------
export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id").references(() => tenants.id, {
      onDelete: "cascade",
    }),
    role: text("role", {
      enum: ["super_admin", "admin", "accountant"],
    })
      .notNull()
      .default("admin"),
    fullName: text("full_name").notNull(),
    email: text("email").notNull(),
    phone: text("phone"),
    passwordHash: text("password_hash").notNull(),
    avatarUrl: text("avatar_url"),
    status: text("status", {
      enum: ["active", "suspended", "pending", "locked"],
    })
      .notNull()
      .default("active"),
    approvedAt: timestamp("approved_at"),
    approvedBy: uuid("approved_by"),
    lastLoginAt: timestamp("last_login_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (u) => ({
    tenantIdx: index("users_tenant_idx").on(u.tenantId),
    roleIdx: index("users_role_idx").on(u.role),
    emailUnique: unique("users_email_unique").on(u.email),
  })
);

// ---------------------------------------------------------------------------
// Subscribers (ISP customers, per tenant)
// ---------------------------------------------------------------------------
export const subscribers = pgTable(
  "subscribers",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    code: text("code"), // optional auto code
    fullName: text("full_name").notNull(),
    phone: text("phone"),
    secondaryPhone: text("secondary_phone"),
    address: text("address"),
    area: text("area"),
    subscriptionType: text("subscription_type", {
      enum: ["monthly", "quarterly", "semi_annual", "annual"],
    })
      .notNull()
      .default("monthly"),
    monthlyFee: numeric("monthly_fee", { precision: 10, scale: 2 })
      .notNull()
      .default("0"),
    dueDate: text("due_date"), // day of month e.g. "05"
    debtAmount: numeric("debt_amount", { precision: 12, scale: 2 })
      .notNull()
      .default("0"),
    status: text("status", {
      enum: ["active", "expired", "suspended", "cancelled"],
    })
      .notNull()
      .default("active"),
    nextBillingAt: timestamp("next_billing_at"),
    notes: text("notes"),
    createdBy: uuid("created_by"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (s) => ({
    tenantIdx: index("subs_tenant_idx").on(s.tenantId),
    statusIdx: index("subs_status_idx").on(s.status),
    phoneIdx: index("subs_phone_idx").on(s.phone),
    nameIdx: index("subs_name_idx").on(s.fullName),
  })
);

// ---------------------------------------------------------------------------
// Payments
// ---------------------------------------------------------------------------
export const payments = pgTable(
  "payments",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    subscriberId: uuid("subscriber_id")
      .notNull()
      .references(() => subscribers.id, { onDelete: "cascade" }),
    receiptNumber: text("receipt_number").notNull(),
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    method: text("method", {
      enum: ["cash", "card", "transfer", "check", "other"],
    })
      .notNull()
      .default("cash"),
    type: text("type", {
      enum: ["subscription", "debt", "advance", "refund"],
    })
      .notNull()
      .default("subscription"),
    monthsCovered: numeric("months_covered", { precision: 5, scale: 2 })
      .notNull()
      .default("1"),
    note: text("note"),
    receivedBy: uuid("received_by"), // accountant/admin user
    paidAt: timestamp("paid_at").notNull().defaultNow(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (p) => ({
    tenantIdx: index("payments_tenant_idx").on(p.tenantId),
    subIdx: index("payments_sub_idx").on(p.subscriberId),
    receiptIdx: index("payments_receipt_idx").on(p.receiptNumber),
    paidAtIdx: index("payments_paid_at_idx").on(p.paidAt),
  })
);

// ---------------------------------------------------------------------------
// Debts ledger (partial/full)
// ---------------------------------------------------------------------------
export const debts = pgTable(
  "debts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    subscriberId: uuid("subscriber_id")
      .notNull()
      .references(() => subscribers.id, { onDelete: "cascade" }),
    paymentId: uuid("payment_id").references(() => payments.id, {
      onDelete: "set null",
    }),
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    remaining: numeric("remaining", { precision: 12, scale: 2 }).notNull(),
    type: text("type", {
      enum: ["charge", "payment", "adjustment"],
    }).notNull(),
    description: text("description"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (d) => ({
    tenantIdx: index("debts_tenant_idx").on(d.tenantId),
    subIdx: index("debts_sub_idx").on(d.subscriberId),
  })
);

// ---------------------------------------------------------------------------
// Invoices
// ---------------------------------------------------------------------------
export const invoices = pgTable(
  "invoices",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    subscriberId: uuid("subscriber_id")
      .notNull()
      .references(() => subscribers.id, { onDelete: "cascade" }),
    invoiceNumber: text("invoice_number").notNull(),
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    status: text("status", {
      enum: ["draft", "issued", "paid", "overdue", "cancelled"],
    })
      .notNull()
      .default("issued"),
    issuedAt: timestamp("issued_at").notNull().defaultNow(),
    dueAt: timestamp("due_at"),
    paidAt: timestamp("paid_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (i) => ({
    tenantIdx: index("invoices_tenant_idx").on(i.tenantId),
  })
);

// ---------------------------------------------------------------------------
// Subscription renewal logs
// ---------------------------------------------------------------------------
export const subscriptionLogs = pgTable(
  "subscription_logs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    kind: text("kind", {
      enum: ["created", "renewed", "upgraded", "downgraded", "expired", "locked", "reactivated"],
    }).notNull(),
    fromPlan: text("from_plan"),
    toPlan: text("to_plan"),
    startsAt: timestamp("starts_at"),
    endsAt: timestamp("ends_at"),
    actorId: uuid("actor_id"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (l) => ({
    tenantIdx: index("sub_logs_tenant_idx").on(l.tenantId),
  })
);

// ---------------------------------------------------------------------------
// Receipt template / company receipt configuration
// ---------------------------------------------------------------------------
export const receiptTemplates = pgTable("receipt_templates", {
  id: uuid("id").primaryKey().defaultRandom(),
  tenantId: uuid("tenant_id")
    .notNull()
    .references(() => tenants.id, { onDelete: "cascade" })
    .unique(),
  headerTitle: text("header_title"),
  footerText: text("footer_text"),
  showLogo: boolean("show_logo").default(true),
  showPhone: boolean("show_phone").default(true),
  showAddress: boolean("show_address").default(true),
  accentColor: text("accent_color").default("#0ea5e9"),
  thankYouMessage: text("thank_you_message"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ---------------------------------------------------------------------------
// Global / tenant settings
// ---------------------------------------------------------------------------
export const settings = pgTable("settings", {
  id: uuid("id").primaryKey().defaultRandom(),
  tenantId: uuid("tenant_id").references(() => tenants.id, {
    onDelete: "cascade",
  }),
  key: text("key").notNull(),
  value: jsonb("value").$type<unknown>(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ---------------------------------------------------------------------------
// Audit logs
// ---------------------------------------------------------------------------
export const auditLogs = pgTable(
  "audit_logs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id").references(() => tenants.id, {
      onDelete: "cascade",
    }),
    actorId: uuid("actor_id"),
    actorName: text("actor_name"),
    action: text("action").notNull(),
    entity: text("entity").notNull(),
    entityId: text("entity_id"),
    meta: jsonb("meta").$type<Record<string, unknown>>(),
    ip: text("ip"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (a) => ({
    tenantIdx: index("audit_tenant_idx").on(a.tenantId),
    actorIdx: index("audit_actor_idx").on(a.actorId),
  })
);

export type Tenant = typeof tenants.$inferSelect;
export type NewTenant = typeof tenants.$inferInsert;
export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type Subscriber = typeof subscribers.$inferSelect;
export type NewSubscriber = typeof subscribers.$inferInsert;
export type Payment = typeof payments.$inferSelect;
export type NewPayment = typeof payments.$inferInsert;
export type Debt = typeof debts.$inferSelect;
export type Invoice = typeof invoices.$inferSelect;
export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
